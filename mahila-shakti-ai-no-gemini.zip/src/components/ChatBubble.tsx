import React, { useState } from "react";
import {
  Bookmark,
  Check,
  Copy,
  RotateCcw,
  Volume2,
  VolumeX,
  AlertCircle,
  CornerUpLeft,
} from "lucide-react";
import { ChatMessage } from "../types/chat";
import { FormattedMessage } from "./FormattedMessage";

interface ChatBubbleProps {
  message: ChatMessage;
  isLatestModelMessage: boolean;
  onTogglePin: (messageId: string) => void;
  onRegenerate: () => void;
  onReusePrompt: (text: string) => void;
  speakingMessageId: string | null;
  onToggleSpeak: (message: ChatMessage) => void;
  onOpenImageCreatorWithPrompt?: (prompt: string) => void;
}

function isImagePrompt(text: string): boolean {
  const t = text.toLowerCase();
  return (
    t.includes("चित्र") ||
    t.includes("तस्वीर") ||
    t.includes("साड़ी") ||
    t.includes("फोटो") ||
    t.includes("सिनेमैटिक") ||
    t.includes("portrait") ||
    t.includes("painting") ||
    t.includes("cinematic") ||
    t.includes("image") ||
    t.includes("generate image") ||
    t.includes("create image")
  );
}

function extractPromptFromDalle(text: string): string {
  try {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed.action_input?.prompt) return parsed.action_input.prompt;
      if (typeof parsed.action_input === "string") return parsed.action_input;
      if (parsed.args?.prompt) return parsed.args.prompt;
      if (parsed.input?.prompt) return parsed.input.prompt;
      if (parsed.prompt) return parsed.prompt;
    }
  } catch {
    // fallback
  }
  const clean = text
    .replace(/\{[\s\S]*\}/g, "")
    .replace(/dalle\.text2im/gi, "")
    .replace(/action[:_]?[a-z0-9._]*/gi, "")
    .trim();
  return clean || "एक भारतीय महिला हरे और गुलाबी रंग की सुंदर साड़ी";
}

function formatTime(timestamp: number): string {
  try {
    return new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(new Date(timestamp));
  } catch {
    return "";
  }
}

function countWords(text: string): number {
  const cleaned = text.trim();
  if (!cleaned) return 0;
  return cleaned.split(/\s+/).length;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({
  message,
  isLatestModelMessage,
  onTogglePin,
  onRegenerate,
  onReusePrompt,
  speakingMessageId,
  onToggleSpeak,
  onOpenImageCreatorWithPrompt,
}) => {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === "user";
  const isSpeaking = speakingMessageId === message.id;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Ignore clipboard failures
    }
  };

  if (isUser) {
    return (
      <div className="flex flex-col items-end group">
        <div className="max-w-[86%] sm:max-w-[75%] rounded-2xl rounded-br-xs bg-slate-900 dark:bg-teal-700 text-white px-4 py-3 shadow-xs">
          <FormattedMessage text={message.text} isUser={true} />
        </div>

        {/* Unboxed quiet metadata + quick reuse action */}
        <div className="flex items-center gap-2 mt-1 px-1 text-xs text-slate-400 dark:text-slate-500 font-mono tabular-nums">
          <span>You</span>
          <span aria-hidden="true">·</span>
          <span>{formatTime(message.timestamp)}</span>
          <span aria-hidden="true">·</span>
          <button
            type="button"
            onClick={() => onReusePrompt(message.text)}
            className="font-sans text-xs text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 inline-flex items-center gap-1 py-1 px-1.5 rounded transition-colors cursor-pointer"
            title="Load message into input box"
          >
            <CornerUpLeft className="w-3 h-3" />
            <span>Edit</span>
          </button>
          {onOpenImageCreatorWithPrompt && isImagePrompt(message.text) && (
            <>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                onClick={() => onOpenImageCreatorWithPrompt(message.text)}
                className="font-sans text-xs text-teal-600 dark:text-teal-400 hover:text-teal-700 dark:hover:text-teal-300 inline-flex items-center gap-1 py-1 px-1.5 rounded transition-colors cursor-pointer font-medium"
                title="Open in Image Creator"
              >
                <span>🖼️ Create Image</span>
              </button>
            </>
          )}
        </div>
      </div>
    );
  }

  const wordCount = countWords(message.text);

  return (
    <div className="flex flex-col items-start">
      {/* Unboxed quiet metadata header (Zero-Pill Discipline) */}
      <div className="flex items-center gap-2 mb-1.5 px-1 text-xs text-slate-500 dark:text-slate-400">
        <span className="font-semibold text-slate-800 dark:text-slate-200">
          Mahila Shakti AI
        </span>
        <span aria-hidden="true">·</span>
        <span className="font-mono tabular-nums">
          {formatTime(message.timestamp)}
        </span>
        {!message.isStreaming && wordCount > 0 && (
          <>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{wordCount} words</span>
          </>
        )}
        {message.pinned && (
          <>
            <span aria-hidden="true">·</span>
            <span className="text-teal-700 dark:text-teal-400 font-medium">
              Saved
            </span>
          </>
        )}
      </div>

      {/* Main AI Response Bubble */}
      <div
        className={`w-full max-w-[95%] sm:max-w-[85%] rounded-2xl rounded-tl-xs px-4 py-3.5 sm:px-5 sm:py-4 border transition-colors ${
          message.isError
            ? "bg-red-50/80 dark:bg-red-950/30 border-red-200 dark:border-red-900/60 text-red-900 dark:text-red-200"
            : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 shadow-2xs"
        }`}
      >
        {message.isError && (
          <div className="flex items-center gap-2 text-red-700 dark:text-red-400 text-xs font-semibold mb-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>Response Interrupted</span>
          </div>
        )}

        {message.text &&
        (message.text.includes("dalle.text2im") ||
          message.text.includes('"action": "dalle') ||
          message.text.includes('"action":"dalle') ||
          message.text.includes("text2im") ||
          (message.text.trim().startsWith("{") && message.text.includes('"action"'))) ? (
          <div className="space-y-3 py-1">
            <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
              This request describes an image. Tap below to generate and download the actual artwork in the Image Creator:
            </p>
            {onOpenImageCreatorWithPrompt && (
              <button
                type="button"
                onClick={() =>
                  onOpenImageCreatorWithPrompt(
                    extractPromptFromDalle(message.text)
                  )
                }
                className="min-h-[44px] px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs inline-flex items-center gap-2 shadow-xs transition-all cursor-pointer"
              >
                <span>🖼️ Generate Image Now · चित्र बनाएं</span>
              </button>
            )}
          </div>
        ) : message.text ? (
          <FormattedMessage text={message.text} isUser={false} />
        ) : (
          <div className="flex items-center gap-2.5 py-1 text-sm text-slate-500 dark:text-slate-400">
            <span className="inline-flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-teal-600 dark:bg-teal-400 animate-pulse" />
              <span
                className="w-2 h-2 rounded-full bg-teal-600 dark:bg-teal-400 animate-pulse"
                style={{ animationDelay: "150ms" }}
              />
              <span
                className="w-2 h-2 rounded-full bg-teal-600 dark:bg-teal-400 animate-pulse"
                style={{ animationDelay: "300ms" }}
              />
            </span>
            <span>Composing detailed response...</span>
          </div>
        )}

        {message.isStreaming && message.text && (
          <div className="mt-2.5 flex items-center gap-2 text-xs text-teal-700 dark:text-teal-400">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-600 dark:bg-teal-400 animate-ping" />
            <span>Streaming response...</span>
          </div>
        )}

        {/* Ergonomic Touch Action Bar (Minimum 44px touch targets for Android) */}
        {!message.isStreaming && message.text && (
          <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center flex-wrap gap-1 -mx-1.5">
            <button
              type="button"
              onClick={handleCopy}
              className="min-h-[44px] px-3 rounded-lg inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-slate-800/60 active:scale-[0.98] transition-all whitespace-nowrap cursor-pointer"
              aria-label="Copy response text"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                  <span className="text-teal-700 dark:text-teal-400">
                    Copied
                  </span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => onToggleSpeak(message)}
              className={`min-h-[44px] px-3 rounded-lg inline-flex items-center gap-1.5 text-xs font-medium active:scale-[0.98] transition-all whitespace-nowrap cursor-pointer ${
                isSpeaking
                  ? "text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/60"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-slate-800/60"
              }`}
              aria-label={isSpeaking ? "Stop reading aloud" : "Read response aloud"}
            >
              {isSpeaking ? (
                <>
                  <VolumeX className="w-3.5 h-3.5" />
                  <span>Stop Audio</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Listen</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => onTogglePin(message.id)}
              className={`min-h-[44px] px-3 rounded-lg inline-flex items-center gap-1.5 text-xs font-medium active:scale-[0.98] transition-all whitespace-nowrap cursor-pointer ${
                message.pinned
                  ? "text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/60"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-slate-800/60"
              }`}
              aria-label={
                message.pinned ? "Remove from saved notes" : "Save to session notes"
              }
            >
              <Bookmark
                className={`w-3.5 h-3.5 ${
                  message.pinned ? "fill-current" : ""
                }`}
              />
              <span>{message.pinned ? "Saved" : "Save"}</span>
            </button>

            {isLatestModelMessage && (
              <button
                type="button"
                onClick={onRegenerate}
                className="min-h-[44px] px-3 rounded-lg inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-slate-800/60 active:scale-[0.98] transition-all whitespace-nowrap cursor-pointer ml-auto"
                aria-label="Regenerate response"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retry</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
