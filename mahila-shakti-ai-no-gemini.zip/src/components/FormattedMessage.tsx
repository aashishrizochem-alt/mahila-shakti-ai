import React, { useState } from "react";
import { Check, Copy } from "lucide-react";

interface FormattedMessageProps {
  text: string;
  isUser?: boolean;
}

interface ParsedBlock {
  type: "code" | "text";
  content: string;
  language?: string;
}

function parseCodeBlocks(raw: string): ParsedBlock[] {
  const blocks: ParsedBlock[] = [];
  const regex = /```([a-zA-Z0-9_-]*)\n?([\s\S]*?)```/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(raw)) !== null) {
    if (match.index > lastIndex) {
      blocks.push({
        type: "text",
        content: raw.slice(lastIndex, match.index),
      });
    }
    blocks.push({
      type: "code",
      language: match[1]?.trim() || "code",
      content: match[2].replace(/\n$/, ""),
    });
    lastIndex = regex.lastIndex;
  }

  if (lastIndex < raw.length) {
    blocks.push({
      type: "text",
      content: raw.slice(lastIndex),
    });
  }

  return blocks;
}

function renderInlineFormatting(text: string, isUser: boolean): React.ReactNode[] {
  // Split by inline code `...`, bold **...**, and italic *...*
  const tokens = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*\n]+\*)/g);

  return tokens.map((token, idx) => {
    if (token.startsWith("`") && token.endsWith("`") && token.length > 2) {
      return (
        <code
          key={idx}
          className={`font-mono text-[13px] px-1.5 py-0.5 rounded ${
            isUser
              ? "bg-white/15 text-white"
              : "bg-slate-100 dark:bg-slate-800 text-teal-800 dark:text-teal-300"
          }`}
        >
          {token.slice(1, -1)}
        </code>
      );
    }
    if (token.startsWith("**") && token.endsWith("**") && token.length > 4) {
      return (
        <strong
          key={idx}
          className={
            isUser
              ? "font-semibold text-white"
              : "font-semibold text-slate-900 dark:text-white"
          }
        >
          {token.slice(2, -2)}
        </strong>
      );
    }
    if (token.startsWith("*") && token.endsWith("*") && token.length > 2) {
      return (
        <em key={idx} className="italic">
          {token.slice(1, -1)}
        </em>
      );
    }
    return <React.Fragment key={idx}>{token}</React.Fragment>;
  });
}

function CodeBlockItem({
  code,
  language,
}: {
  code: string;
  language: string;
}) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Fallback copy
    }
  };

  return (
    <div className="my-3 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-950 text-slate-100">
      <div className="flex items-center justify-between px-3.5 py-1.5 bg-slate-900 border-b border-slate-800 text-xs text-slate-400">
        <span className="font-mono lowercase">{language || "snippet"}</span>
        <button
          type="button"
          onClick={handleCopy}
          className="min-h-[36px] px-2.5 flex items-center gap-1.5 text-xs font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
          aria-label="Copy code snippet"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-teal-400" />
              <span className="text-teal-400">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>
      <pre className="p-3.5 text-[13px] leading-relaxed font-mono overflow-x-auto">
        <code>{code}</code>
      </pre>
    </div>
  );
}

export const FormattedMessage: React.FC<FormattedMessageProps> = ({
  text,
  isUser = false,
}) => {
  if (isUser) {
    return (
      <div className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">
        {renderInlineFormatting(text, true)}
      </div>
    );
  }

  const blocks = parseCodeBlocks(text);

  return (
    <div className="space-y-3 text-[15px] leading-[1.65] text-slate-800 dark:text-slate-200 break-words">
      {blocks.map((block, bIdx) => {
        if (block.type === "code") {
          return (
            <CodeBlockItem
              key={bIdx}
              code={block.content}
              language={block.language || "code"}
            />
          );
        }

        const lines = block.content.split("\n");
        const elements: React.ReactNode[] = [];
        let listItems: { ordered: boolean; items: string[] } | null = null;

        const flushList = (keyPrefix: string) => {
          if (!listItems) return;
          if (listItems.ordered) {
            elements.push(
              <ol
                key={`${keyPrefix}-ol`}
                className="list-decimal pl-5 space-y-1.5 my-2 marker:text-slate-400 dark:marker:text-slate-500 marker:font-mono marker:text-xs"
              >
                {listItems.items.map((item, idx) => (
                  <li key={idx} className="pl-1">
                    {renderInlineFormatting(item, false)}
                  </li>
                ))}
              </ol>
            );
          } else {
            elements.push(
              <ul
                key={`${keyPrefix}-ul`}
                className="list-disc pl-5 space-y-1.5 my-2 marker:text-teal-600 dark:marker:text-teal-400"
              >
                {listItems.items.map((item, idx) => (
                  <li key={idx} className="pl-1">
                    {renderInlineFormatting(item, false)}
                  </li>
                ))}
              </ul>
            );
          }
          listItems = null;
        };

        lines.forEach((rawLine, lIdx) => {
          const line = rawLine.trimEnd();
          const trimmed = line.trim();

          if (!trimmed) {
            flushList(`${bIdx}-${lIdx}`);
            return;
          }

          // Headings
          if (trimmed.startsWith("### ")) {
            flushList(`${bIdx}-${lIdx}`);
            elements.push(
              <h4
                key={`${bIdx}-${lIdx}`}
                className="text-base font-semibold text-slate-900 dark:text-white pt-2 pb-0.5"
              >
                {renderInlineFormatting(trimmed.slice(4), false)}
              </h4>
            );
            return;
          }
          if (trimmed.startsWith("## ")) {
            flushList(`${bIdx}-${lIdx}`);
            elements.push(
              <h3
                key={`${bIdx}-${lIdx}`}
                className="text-[17px] font-semibold text-slate-900 dark:text-white pt-2.5 pb-0.5"
              >
                {renderInlineFormatting(trimmed.slice(3), false)}
              </h3>
            );
            return;
          }
          if (trimmed.startsWith("# ")) {
            flushList(`${bIdx}-${lIdx}`);
            elements.push(
              <h2
                key={`${bIdx}-${lIdx}`}
                className="text-lg font-semibold text-slate-900 dark:text-white pt-3 pb-1"
              >
                {renderInlineFormatting(trimmed.slice(2), false)}
              </h2>
            );
            return;
          }

          // Blockquotes
          if (trimmed.startsWith("> ")) {
            flushList(`${bIdx}-${lIdx}`);
            elements.push(
              <blockquote
                key={`${bIdx}-${lIdx}`}
                className="border-l-2 border-teal-600 dark:border-teal-500 pl-3.5 py-0.5 my-2 italic text-slate-600 dark:text-slate-300"
              >
                {renderInlineFormatting(trimmed.slice(2), false)}
              </blockquote>
            );
            return;
          }

          // Unordered list item
          const ulMatch = trimmed.match(/^[-*•]\s+(.*)/);
          if (ulMatch) {
            if (listItems && listItems.ordered) {
              flushList(`${bIdx}-${lIdx}`);
            }
            if (!listItems) {
              listItems = { ordered: false, items: [] };
            }
            listItems.items.push(ulMatch[1]);
            return;
          }

          // Ordered list item
          const olMatch = trimmed.match(/^\d+\.\s+(.*)/);
          if (olMatch) {
            if (listItems && !listItems.ordered) {
              flushList(`${bIdx}-${lIdx}`);
            }
            if (!listItems) {
              listItems = { ordered: true, items: [] };
            }
            listItems.items.push(olMatch[1]);
            return;
          }

          // Regular paragraph line
          flushList(`${bIdx}-${lIdx}`);
          elements.push(
            <p key={`${bIdx}-${lIdx}`} className="leading-[1.65]">
              {renderInlineFormatting(trimmed, false)}
            </p>
          );
        });

        flushList(`${bIdx}-end`);

        return (
          <div key={bIdx} className="space-y-2.5">
            {elements}
          </div>
        );
      })}
    </div>
  );
};
