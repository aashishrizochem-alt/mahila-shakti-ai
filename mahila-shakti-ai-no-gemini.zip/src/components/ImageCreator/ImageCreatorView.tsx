import React, { useState, useEffect, useRef } from "react";
import {
  Download,
  RotateCcw,
  Sparkles,
  Upload,
  X,
  Image as ImageIcon,
  Copy,
  Check,
  Maximize2,
  Mic,
  MicOff,
  Trash2,
  AlertCircle,
  Clock,
  Layers,
  Info,
  Sliders,
  ShieldCheck,
  RefreshCw,
  FileImage,
} from "lucide-react";
import {
  ASPECT_RATIOS,
  AspectRatio,
  GeneratedImageItem,
  IMAGE_STYLES,
  ImageCreationMode,
  ImageStyle,
  PROMPT_EXAMPLES,
} from "../../types/imageCreator";
import {
  addStoredImage,
  deleteStoredImage,
  loadStoredImages,
  syncImagesFromIndexedDB,
} from "../../utils/imageStorage";

interface ImageCreatorViewProps {
  onBackToChat?: () => void;
  initialPrompt?: string;
}

export const EDIT_PROMPT_EXAMPLES = [
  {
    title: "साड़ी का रंग गुलाबी करें",
    prompt:
      "इस uploaded महिला की यही फोटो रखो, चेहरा और पहचान जैसी है वैसी रहे, केवल साड़ी का रंग बदलकर गहरा गुलाबी कर दो",
  },
  {
    title: "पारंपरिक आभूषण जोड़ें",
    prompt:
      "चेहरा, वस्त्र और मुद्रा समान रखें, पारंपरिक सोने के झुमके, चूड़ियां और मांग टीका जोड़ें",
  },
  {
    title: "पृष्ठभूमि बगीचा करें",
    prompt:
      "महिला और साड़ी का स्वरूप वही रखें, पृष्ठभूमि बदलकर फूलों वाला सुंदर प्राकृतिक बगीचा कर दें",
  },
  {
    title: "Change Dress to Royal Blue",
    prompt:
      "Keep the exact same face, identity and pose from reference, change the dress to royal blue silk saree with golden embroidery",
  },
];

// Client-side image resize helper to prevent huge payloads and Android browser lag
function processImageFile(
  file: File
): Promise<{ dataUrl: string; width: number; height: number; sizeKB: number }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Failed to read image file."));
    reader.onload = (e) => {
      const src = e.target?.result as string;
      const img = new Image();
      img.onerror = () => reject(new Error("Invalid image format."));
      img.onload = () => {
        const MAX_DIM = 1024;
        let w = img.width;
        let h = img.height;
        if (w > MAX_DIM || h > MAX_DIM) {
          if (w > h) {
            h = Math.round((h * MAX_DIM) / w);
            w = MAX_DIM;
          } else {
            w = Math.round((w * MAX_DIM) / h);
            h = MAX_DIM;
          }
        }
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve({
            dataUrl: src,
            width: img.width,
            height: img.height,
            sizeKB: Math.round(file.size / 1024),
          });
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        const compressedDataUrl = canvas.toDataURL("image/jpeg", 0.88);
        const approxSizeKB = Math.round(
          (compressedDataUrl.length * 3) / 4 / 1024
        );
        resolve({
          dataUrl: compressedDataUrl,
          width: w,
          height: h,
          sizeKB: approxSizeKB,
        });
      };
      img.src = src;
    };
    reader.readAsDataURL(file);
  });
}

export const ImageCreatorView: React.FC<ImageCreatorViewProps> = ({
  onBackToChat,
  initialPrompt,
}) => {
  const [creationMode, setCreationMode] =
    useState<ImageCreationMode>("text-to-image");

  const [prompt, setPrompt] = useState(initialPrompt || "");

  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      setPrompt(initialPrompt.trim());
    }
  }, [initialPrompt]);

  const [selectedStyle, setSelectedStyle] = useState<ImageStyle>("realistic");
  const [selectedAspectRatio, setSelectedAspectRatio] =
    useState<AspectRatio>("1:1");
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  const [referenceImageName, setReferenceImageName] = useState<string>("");
  const [referenceImageMeta, setReferenceImageMeta] = useState<{
    width: number;
    height: number;
    sizeKB: number;
  } | null>(null);

  const [isGenerating, setIsGenerating] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [currentImage, setCurrentImage] = useState<GeneratedImageItem | null>(
    null
  );
  const [recentImages, setRecentImages] = useState<GeneratedImageItem[]>(() =>
    loadStoredImages()
  );

  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);
  const [isListeningMic, setIsListeningMic] = useState(false);
  const [activeTab, setActiveTab] = useState<"create" | "gallery">("create");

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const recognitionRef = useRef<any>(null);

  // Sync images from IndexedDB on startup
  useEffect(() => {
    syncImagesFromIndexedDB().then((idbImages) => {
      if (idbImages && idbImages.length > 0) {
        setRecentImages((prev) => {
          if (idbImages.length > prev.length) {
            return idbImages;
          }
          return prev;
        });
      }
    });
  }, []);

  // Web Speech recognition for voice prompts (supports Hindi and English)
  const handleToggleVoiceInput = () => {
    if (isListeningMic && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListeningMic(false);
      return;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SpeechRecognitionAPI =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (!SpeechRecognitionAPI) {
      alert(
        "Voice input is not supported by your browser. Please type your prompt."
      );
      return;
    }

    const recognition = new SpeechRecognitionAPI();
    recognition.lang = "hi-IN";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    recognition.onresult = (event: any) => {
      const transcript = event.results?.[0]?.[0]?.transcript;
      if (transcript) {
        setPrompt((prev) => (prev ? `${prev} ${transcript}` : transcript));
      }
    };

    recognition.onend = () => setIsListeningMic(false);
    recognition.onerror = () => setIsListeningMic(false);

    recognitionRef.current = recognition;
    setIsListeningMic(true);
    recognition.start();
  };

  // Handle reference image upload with automatic client-side resizing
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
    if (!validTypes.includes(file.type.toLowerCase())) {
      setGenerationError(
        "Please select a valid image file (JPG, JPEG, PNG, or WebP)."
      );
      return;
    }

    try {
      const processed = await processImageFile(file);
      setReferenceImage(processed.dataUrl);
      setReferenceImageName(file.name);
      setReferenceImageMeta({
        width: processed.width,
        height: processed.height,
        sizeKB: processed.sizeKB,
      });
      setGenerationError(null);
      // Auto-switch to Image to Image mode when reference is uploaded
      setCreationMode("image-to-image");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to load image";
      setGenerationError(msg);
    }
  };

  const handleClearReferenceImage = () => {
    setReferenceImage(null);
    setReferenceImageName("");
    setReferenceImageMeta(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Generate Image API call - strictly honors mode and reference image
  const handleGenerate = async (customSeed?: number) => {
    const trimmed = prompt.trim();
    if (!trimmed || isGenerating) return;

    if (creationMode === "image-to-image" && !referenceImage) {
      setGenerationError(
        "Please upload a reference image to use Image to Image / Edit mode, or switch to Text to Image mode."
      );
      return;
    }

    setIsGenerating(true);
    setGenerationError(null);

    const seed = customSeed ?? Math.floor(Math.random() * 1000000);

    try {
      let finalImageUrl = "";
      let finalWidth = 512;
      let finalHeight = 512;

      // 1. Call server-side generation endpoint with mode and reference image
      const res = await fetch("/api/image/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: trimmed,
          mode: creationMode,
          style: selectedStyle,
          aspectRatio: selectedAspectRatio,
          referenceImage:
            creationMode === "image-to-image" ? referenceImage : undefined,
          referenceImageName:
            creationMode === "image-to-image" ? referenceImageName : undefined,
          seed,
        }),
      });

      const data = await res.json();

      if (data?.success && typeof data.imageUrl === "string" && data.imageUrl.startsWith("data:image/")) {
        finalImageUrl = data.imageUrl;
        finalWidth = data.width || 512;
        finalHeight = data.height || 512;
      } else {
        // If image-to-image mode was requested, throw the backend error directly
        if (creationMode === "image-to-image") {
          throw new Error(
            data?.error ||
              "Reference-image generation is not available with the current free backend. To enable image-to-image editing, a compatible image-to-image provider or API key is required."
          );
        }
        console.warn("Server image generator reported:", data?.error);
      }

      // 2. Client fallback ONLY for text-to-image mode if proxy had a transient network timeout
      if (!finalImageUrl && creationMode === "text-to-image") {
        const aspectOpt =
          ASPECT_RATIOS.find((a) => a.id === selectedAspectRatio) ||
          ASPECT_RATIOS[0];
        const styleOpt = IMAGE_STYLES.find((s) => s.id === selectedStyle);
        const styleDesc =
          styleOpt?.description ||
          "photorealistic, high quality, natural lighting";
        const combinedPrompt = `${trimmed}, ${styleDesc}`;
        const encoded = encodeURIComponent(
          combinedPrompt.replace(/[\r\n]+/g, " ").trim()
        );

        const directWidth =
          aspectOpt.id === "16:9" ? 768 : aspectOpt.id === "9:16" ? 432 : 512;
        const directHeight =
          aspectOpt.id === "16:9"
            ? 432
            : aspectOpt.id === "9:16"
            ? 768
            : aspectOpt.id === "4:5"
            ? 640
            : 512;

        const directCandidates = [
          `https://image.pollinations.ai/prompt/${encoded}?width=${directWidth}&height=${directHeight}&seed=${seed}`,
          `https://image.pollinations.ai/prompt/${encoded}?model=dreamshaper&width=${directWidth}&height=${directHeight}&seed=${seed}`,
          `https://image.pollinations.ai/prompt/${encoded}?model=sana&width=${directWidth}&height=${directHeight}&seed=${seed}`,
          `https://image.pollinations.ai/prompt/${encoded}?width=${directWidth}&height=${directHeight}`,
          `https://image.pollinations.ai/prompt/${encoded}`,
        ];

        let directError: Error | null = null;

        for (const directUrl of directCandidates) {
          try {
            const directRes = await fetch(directUrl);
            if (!directRes.ok) {
              if (directRes.status === 402) {
                throw new Error("Free engine reached rate limits (HTTP 402)");
              }
              throw new Error(
                `HTTP ${directRes.status} (${directRes.statusText})`
              );
            }

            const contentType = (
              directRes.headers.get("content-type") || ""
            ).toLowerCase();
            if (
              !contentType.startsWith("image/") &&
              !contentType.includes("octet-stream")
            ) {
              throw new Error("Non-image response");
            }

            const blob = await directRes.blob();
            if (blob.size < 500) {
              throw new Error("Truncated image data");
            }

            finalImageUrl = await new Promise<string>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => resolve(reader.result as string);
              reader.onerror = () =>
                reject(new Error("Failed to process image data"));
              reader.readAsDataURL(blob);
            });
            finalWidth = directWidth;
            finalHeight = directHeight;
            break;
          } catch (err: unknown) {
            directError = err instanceof Error ? err : new Error(String(err));
          }
        }

        if (!finalImageUrl && directError) {
          throw directError;
        }
      }

      if (!finalImageUrl || !finalImageUrl.startsWith("data:image/")) {
        throw new Error(
          "Could not receive a valid image from the image engine. Please check your network and try again."
        );
      }

      const newImageItem: GeneratedImageItem = {
        id: `img-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        imageUrl: finalImageUrl,
        prompt: trimmed,
        mode: creationMode,
        style: selectedStyle,
        aspectRatio: selectedAspectRatio,
        seed,
        createdAt: Date.now(),
        width: finalWidth,
        height: finalHeight,
        referenceImageName:
          creationMode === "image-to-image"
            ? referenceImageName || undefined
            : undefined,
      };

      setCurrentImage(newImageItem);
      const updatedList = addStoredImage(newImageItem);
      setRecentImages(updatedList);
    } catch (err: unknown) {
      const msg =
        err instanceof Error
          ? err.message
          : "Could not complete image generation. Please try again.";
      setGenerationError(msg);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateAgain = () => {
    handleGenerate();
  };

  const handleDownload = (img: GeneratedImageItem) => {
    const a = document.createElement("a");
    a.href = img.imageUrl;
    const cleanPrompt = img.prompt
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .slice(0, 30);
    a.download = `mahila-shakti-${cleanPrompt || "artwork"}-${img.seed}.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleCopyPrompt = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedPrompt(true);
      setTimeout(() => setCopiedPrompt(false), 2000);
    } catch {
      // ignore
    }
  };

  const handleSelectExample = (ex: (typeof PROMPT_EXAMPLES)[0]) => {
    setPrompt(ex.prompt);
    setSelectedStyle(ex.style);
    setSelectedAspectRatio(ex.aspectRatio);
  };

  const handleSelectEditExample = (ex: (typeof EDIT_PROMPT_EXAMPLES)[0]) => {
    setPrompt(ex.prompt);
  };

  const handleDeleteHistoryItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = deleteStoredImage(id);
    setRecentImages(updated);
    if (currentImage?.id === id) {
      setCurrentImage(updated[0] || null);
    }
  };

  const currentAspect =
    ASPECT_RATIOS.find(
      (a) => a.id === (currentImage?.aspectRatio || selectedAspectRatio)
    ) || ASPECT_RATIOS[0];

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-y-auto">
      {/* Top Bar inside Image Creator */}
      <div className="shrink-0 px-4 sm:px-6 py-3 border-b border-slate-200/80 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 z-10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-teal-500 to-indigo-600 text-white flex items-center justify-center shadow-xs">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-semibold tracking-tight text-slate-900 dark:text-white">
                Image Creator · चित्र निर्माण
              </h1>
              <span className="hidden sm:inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wide uppercase bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                Studio Mode
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Hindi & English AI image studio with text-to-image and reference-guided photo editing
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Segmented View Switch */}
          <div className="flex p-0.5 bg-slate-100 dark:bg-slate-800 rounded-lg">
            <button
              type="button"
              onClick={() => setActiveTab("create")}
              className={`min-h-[38px] px-3 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === "create"
                  ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
              }`}
            >
              Studio
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("gallery")}
              className={`min-h-[38px] px-3 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === "gallery"
                  ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
              }`}
            >
              Gallery ({recentImages.length})
            </button>
          </div>

          {onBackToChat && (
            <button
              type="button"
              onClick={onBackToChat}
              className="min-h-[40px] px-3.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
            >
              ← Back to Chat
            </button>
          )}
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 min-h-0">
        {activeTab === "gallery" ? (
          /* Gallery View */
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                  Your Recent Creations
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Stored securely on your device. Click to view, re-use prompt, or download.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab("create")}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-slate-900 dark:bg-teal-600 text-white text-xs font-medium cursor-pointer"
              >
                + Create New Artwork
              </button>
            </div>

            {recentImages.length === 0 ? (
              <div className="py-20 text-center rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 p-8">
                <ImageIcon className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
                <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  No images created yet
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1 mb-4">
                  Enter an image prompt in Hindi or English to generate your first AI artwork.
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab("create")}
                  className="min-h-[42px] px-4 py-2 rounded-xl bg-teal-600 text-white text-xs font-semibold"
                >
                  Start Creating
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3.5">
                {recentImages.map((img) => (
                  <div
                    key={img.id}
                    onClick={() => {
                      setCurrentImage(img);
                      setPrompt(img.prompt);
                      setSelectedStyle(img.style);
                      setSelectedAspectRatio(img.aspectRatio);
                      if (img.mode) setCreationMode(img.mode);
                      setActiveTab("create");
                    }}
                    className="group relative rounded-xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs hover:shadow-md transition-all cursor-pointer"
                  >
                    <div className="aspect-square bg-slate-100 dark:bg-slate-800 relative overflow-hidden">
                      <img
                        src={img.imageUrl}
                        alt={img.prompt}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-2 flex flex-col justify-end">
                        <p className="text-[11px] text-white line-clamp-2 leading-snug">
                          {img.prompt}
                        </p>
                      </div>
                    </div>

                    <div className="p-2 flex items-center justify-between gap-1 text-[11px] text-slate-500 dark:text-slate-400">
                      <span className="capitalize truncate font-medium">
                        {img.style} · {img.aspectRatio}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => handleDeleteHistoryItem(img.id, e)}
                        className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded text-slate-400 hover:text-red-500 transition-colors"
                        title="Delete image"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* Studio Creator View: 2 Columns on Desktop, 1 Column on Mobile */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Controls & Prompt Input (7 cols) */}
            <div className="lg:col-span-7 space-y-5">
              {/* PRIMARY MODE SELECTOR: Clearly separates Text-to-Image and Image-to-Image / Edit */}
              <div className="grid grid-cols-2 p-1 bg-slate-200/80 dark:bg-slate-800/80 rounded-2xl border border-slate-300/80 dark:border-slate-700/80">
                <button
                  type="button"
                  onClick={() => {
                    setCreationMode("text-to-image");
                    setGenerationError(null);
                  }}
                  className={`min-h-[46px] px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    creationMode === "text-to-image"
                      ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  <Sparkles className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                  <span>✨ Text to Image</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCreationMode("image-to-image");
                    setGenerationError(null);
                  }}
                  className={`min-h-[46px] px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    creationMode === "image-to-image"
                      ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  <Layers className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  <span>🖼️ Image to Image / Edit</span>
                </button>
              </div>

              {/* IMAGE-TO-IMAGE SPECIFIC REFERENCE CARD (Shown prominently when in image-to-image mode) */}
              {creationMode === "image-to-image" && (
                <div className="rounded-2xl border-2 border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/40 dark:bg-indigo-950/20 p-4 sm:p-5 shadow-xs space-y-3.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileImage className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                        Primary Reference Image · मूल संदर्भ फोटो
                      </label>
                    </div>
                    {referenceImage && (
                      <button
                        type="button"
                        onClick={handleClearReferenceImage}
                        className="text-xs text-red-600 hover:text-red-700 dark:text-red-400 flex items-center gap-1 font-medium cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Remove Photo</span>
                      </button>
                    )}
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/jpg"
                    onChange={handleFileChange}
                    className="hidden"
                  />

                  {referenceImage ? (
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3.5 p-3 rounded-xl border border-indigo-200 dark:border-indigo-800/70 bg-white dark:bg-slate-900 shadow-2xs">
                      <div className="relative group shrink-0">
                        <img
                          src={referenceImage}
                          alt="Uploaded reference"
                          className="w-20 h-20 sm:w-24 sm:h-24 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shadow-xs"
                          referrerPolicy="no-referrer"
                        />
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="absolute inset-0 bg-black/50 text-white opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center text-[10px] font-medium"
                        >
                          Change
                        </button>
                      </div>
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex items-center gap-1.5">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-indigo-100 dark:bg-indigo-900/60 text-indigo-800 dark:text-indigo-300">
                            Reference Locked
                          </span>
                          {referenceImageMeta && (
                            <span className="text-[10px] text-slate-500 font-mono">
                              {referenceImageMeta.width}×{referenceImageMeta.height} · {referenceImageMeta.sizeKB}KB
                            </span>
                          )}
                        </div>
                        <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                          {referenceImageName || "Uploaded Photo"}
                        </p>
                        <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                          Subject identity, face structure, pose, and composition are locked from this photo. The model will only apply your requested edits below.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-indigo-300 dark:border-indigo-800 hover:border-indigo-500 dark:hover:border-indigo-500 rounded-xl p-5 flex flex-col items-center justify-center text-center gap-2 cursor-pointer transition-colors bg-white/70 dark:bg-slate-900/70"
                    >
                      <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                        <Upload className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200">
                          Upload reference photo to edit · फोटो अपलोड करें
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                          Supports JPG, JPEG, PNG, and WebP (auto-optimized on device)
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Identity Preservation Rule */}
                  <div className="flex items-start gap-2 p-2.5 rounded-lg bg-indigo-100/60 dark:bg-indigo-950/40 text-[11px] text-indigo-900 dark:text-indigo-300">
                    <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-indigo-600 dark:text-indigo-400" />
                    <p className="leading-relaxed">
                      <strong>Preservation Contract:</strong> The subject's face, identity, pose, and camera angle are preserved. Only specify the exact elements you wish to modify (e.g. saree color, background, jewelry).
                    </p>
                  </div>
                </div>
              )}

              {/* 1. Large Prompt Box with Hindi and English support */}
              <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <label
                    htmlFor="prompt-input"
                    className="text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5"
                  >
                    <span>
                      {creationMode === "image-to-image"
                        ? "Edit Instructions / संपादन निर्देश"
                        : "Image Prompt / वर्णन"}
                    </span>
                    <span className="text-[10px] font-normal text-slate-400 normal-case">
                      (Hindi & English supported)
                    </span>
                  </label>

                  <div className="flex items-center gap-1.5">
                    {prompt && (
                      <button
                        type="button"
                        onClick={() => setPrompt("")}
                        className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 px-1.5 py-0.5"
                      >
                        Clear
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={handleToggleVoiceInput}
                      className={`min-h-[38px] px-2.5 rounded-lg flex items-center gap-1.5 text-xs font-medium transition-colors cursor-pointer ${
                        isListeningMic
                          ? "bg-red-500 text-white animate-pulse"
                          : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                      }`}
                      title={
                        isListeningMic
                          ? "Stop recording"
                          : "Speak prompt (Hindi or English)"
                      }
                    >
                      {isListeningMic ? (
                        <>
                          <MicOff className="w-3.5 h-3.5" />
                          <span>Listening...</span>
                        </>
                      ) : (
                        <>
                          <Mic className="w-3.5 h-3.5" />
                          <span>Voice Input</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                <div className="relative">
                  <textarea
                    id="prompt-input"
                    rows={4}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder={
                      creationMode === "image-to-image"
                        ? "जैसे: 'इस uploaded महिला की यही फोटो रखो, चेहरा और पहचान जैसी है वैसी रहे, केवल साड़ी का रंग बदलकर गहरा गुलाबी कर दो'"
                        : "Enter your prompt in Hindi or English... जैसे: 'एक भारतीय महिला हरे और गुलाबी रंग की सुंदर कढ़ाईदार साड़ी पहने हुए, सिनेमैटिक फोटो, प्राकृतिक प्रकाश'"
                    }
                    className="w-full p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/70 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 text-sm sm:text-base leading-relaxed focus:outline-hidden focus:ring-2 focus:ring-teal-500/50 resize-y transition-all min-h-[110px]"
                  />
                  <div className="absolute right-2.5 bottom-2.5 text-[10px] text-slate-400 font-mono">
                    {prompt.length} chars
                  </div>
                </div>

                {/* Example Prompts Carousel / Chips */}
                <div className="space-y-1.5 pt-1">
                  <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1">
                    <span>
                      {creationMode === "image-to-image"
                        ? "Try sample edit instructions:"
                        : "Try sample prompts:"}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {creationMode === "image-to-image"
                      ? EDIT_PROMPT_EXAMPLES.map((ex, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => handleSelectEditExample(ex)}
                            className="text-xs px-2.5 py-1.5 rounded-lg bg-indigo-50/80 dark:bg-indigo-950/50 text-indigo-900 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/80 border border-indigo-200 dark:border-indigo-800 transition-colors text-left truncate max-w-full cursor-pointer"
                            title={ex.prompt}
                          >
                            ✏️ {ex.title}
                          </button>
                        ))
                      : PROMPT_EXAMPLES.map((ex, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => handleSelectExample(ex)}
                            className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 hover:text-teal-700 dark:hover:text-teal-300 border border-slate-200/60 dark:border-slate-700 transition-colors text-left truncate max-w-full cursor-pointer"
                            title={ex.prompt}
                          >
                            {ex.language === "hi" ? "🇮🇳 " : "✨ "}
                            {ex.title}
                          </button>
                        ))}
                  </div>
                </div>
              </div>

              {/* 2. Options: Style Selection */}
              <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Artistic Style / शैली
                  </label>
                  <span className="text-xs text-slate-500 capitalize">
                    {IMAGE_STYLES.find((s) => s.id === selectedStyle)?.label}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {IMAGE_STYLES.map((style) => {
                    const isSelected = selectedStyle === style.id;
                    return (
                      <button
                        key={style.id}
                        type="button"
                        onClick={() => setSelectedStyle(style.id)}
                        className={`min-h-[50px] p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                          isSelected
                            ? "border-teal-600 bg-teal-50/80 dark:bg-teal-950/40 text-teal-950 dark:text-teal-200 ring-2 ring-teal-600/30"
                            : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-950/50 text-slate-700 dark:text-slate-300"
                        }`}
                      >
                        <div className="flex items-center justify-between w-full">
                          <span className="text-base">{style.badge}</span>
                          {isSelected && (
                            <Check className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                          )}
                        </div>
                        <div className="mt-1">
                          <div className="text-xs font-semibold leading-tight">
                            {style.label}
                          </div>
                          <div className="text-[10px] text-slate-400 truncate">
                            {style.labelHi}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 3. Options: Aspect Ratio Selection */}
              <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Aspect Ratio / अनुपात
                  </label>
                  <span className="text-xs text-slate-500">
                    {
                      ASPECT_RATIOS.find((a) => a.id === selectedAspectRatio)
                        ?.sublabel
                    }
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-2">
                  {ASPECT_RATIOS.map((ratio) => {
                    const isSelected = selectedAspectRatio === ratio.id;
                    return (
                      <button
                        key={ratio.id}
                        type="button"
                        onClick={() => setSelectedAspectRatio(ratio.id)}
                        className={`min-h-[56px] p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                          isSelected
                            ? "border-teal-600 bg-teal-50/80 dark:bg-teal-950/40 text-teal-950 dark:text-teal-200 ring-2 ring-teal-600/30"
                            : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-950/50 text-slate-700 dark:text-slate-300"
                        }`}
                      >
                        <div
                          className="border border-current rounded-xs opacity-75"
                          style={{
                            width: `${Math.min(
                              22,
                              16 * (ratio.widthRatio / ratio.heightRatio)
                            )}px`,
                            height: `${Math.min(
                              22,
                              16 * (ratio.heightRatio / ratio.widthRatio)
                            )}px`,
                          }}
                        />
                        <span className="text-xs font-semibold leading-none">
                          {ratio.label}
                        </span>
                        <span className="text-[10px] text-slate-400 leading-none">
                          {ratio.sublabel}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 4. Error banner if generation failed */}
              {generationError && (
                <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900/60 text-xs text-red-800 dark:text-red-300 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-red-500" />
                  <div className="flex-1 space-y-1">
                    <p className="font-bold text-sm">
                      {creationMode === "image-to-image"
                        ? "Image-to-Image / Reference Notice"
                        : "Image Generation Notice"}
                    </p>
                    <p className="leading-relaxed">{generationError}</p>
                    {creationMode === "image-to-image" && (
                      <div className="pt-2">
                        <button
                          type="button"
                          onClick={() => {
                            setCreationMode("text-to-image");
                            setGenerationError(null);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-red-100 hover:bg-red-200 dark:bg-red-900/60 dark:hover:bg-red-900 text-red-900 dark:text-red-200 font-semibold text-xs transition-colors cursor-pointer"
                        >
                          Switch to ✨ Text to Image Mode
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* 5. Primary Action: Generate Image Button */}
              <button
                type="button"
                onClick={() => handleGenerate()}
                disabled={!prompt.trim() || isGenerating}
                className={`w-full min-h-[52px] rounded-xl text-white font-semibold text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-sm active:scale-[0.99] transition-all cursor-pointer ${
                  creationMode === "image-to-image"
                    ? "bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
                    : "bg-slate-900 dark:bg-teal-600 hover:bg-slate-800 dark:hover:bg-teal-500 disabled:opacity-50 disabled:cursor-not-allowed"
                }`}
              >
                {isGenerating ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>
                      {creationMode === "image-to-image"
                        ? "Processing Image Edit... / फोटो संपादित हो रही है..."
                        : "Generating Artwork with AI... / चित्र बन रहा है..."}
                    </span>
                  </>
                ) : (
                  <>
                    {creationMode === "image-to-image" ? (
                      <>
                        <Layers className="w-5 h-5" />
                        <span>Apply Image Edit · फोटो संपादित करें</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        <span>Generate Image · चित्र बनाएं</span>
                      </>
                    )}
                  </>
                )}
              </button>

              {/* Engine & Free Tier Notice */}
              <div className="p-3 rounded-xl bg-slate-100/70 dark:bg-slate-900/70 border border-slate-200/60 dark:border-slate-800/80 text-[11px] text-slate-500 dark:text-slate-400 flex items-start gap-2">
                <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-teal-600 dark:text-teal-400" />
                <p className="leading-relaxed">
                  <strong>Zero-cost Text-to-Image Engine:</strong> Powered by open community GPU diffusion nodes. High-resolution diffusion generation from descriptive Hindi & English prompts without paid billing.
                </p>
              </div>
            </div>

            {/* Right Column: Image Preview Area (5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <span>Preview / दृश्य</span>
                    {currentImage && (
                      <span className="text-[10px] font-normal text-slate-400 font-mono normal-case">
                        Seed: {currentImage.seed}
                      </span>
                    )}
                  </h3>

                  {currentImage && (
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleCopyPrompt(currentImage.prompt)}
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        title="Copy prompt text"
                      >
                        {copiedPrompt ? (
                          <Check className="w-4 h-4 text-emerald-500" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setFullscreenImage(currentImage.imageUrl)
                        }
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        title="View Fullscreen"
                      >
                        <Maximize2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Aspect-Ratio Preview Container */}
                <div
                  className={`w-full ${currentAspect.aspectClass} max-h-[480px] rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 relative flex items-center justify-center`}
                >
                  {isGenerating ? (
                    /* Animated Loading State */
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-slate-50/90 dark:bg-slate-950/90 backdrop-blur-xs">
                      <div className="relative mb-4">
                        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-teal-500 to-indigo-600 flex items-center justify-center text-white shadow-lg animate-bounce">
                          <Sparkles className="w-7 h-7" />
                        </div>
                        <div className="absolute -inset-1 rounded-2xl bg-teal-500/20 blur-sm animate-pulse" />
                      </div>
                      <h4 className="text-sm font-semibold text-slate-900 dark:text-white">
                        {creationMode === "image-to-image"
                          ? "Executing Image Edit..."
                          : "Synthesizing Artwork..."}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs leading-relaxed">
                        Rendering in {selectedStyle} style with {selectedAspectRatio} aspect ratio
                      </p>
                      <div className="w-40 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full mt-4 overflow-hidden">
                        <div className="h-full bg-teal-500 rounded-full animate-pulse w-3/4" />
                      </div>
                    </div>
                  ) : currentImage ? (
                    /* Rendered Image */
                    <div className="relative w-full h-full group">
                      <img
                        src={currentImage.imageUrl}
                        alt={currentImage.prompt}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  ) : (
                    /* Empty Placeholder Canvas */
                    <div className="p-6 text-center text-slate-400 dark:text-slate-600 flex flex-col items-center justify-center">
                      <div className="w-12 h-12 rounded-xl bg-slate-200/60 dark:bg-slate-800/60 flex items-center justify-center mb-3">
                        <ImageIcon className="w-6 h-6 text-slate-400" />
                      </div>
                      <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
                        {creationMode === "image-to-image"
                          ? "Edited photo preview will appear here"
                          : "Artwork preview will appear here"}
                      </p>
                      <p className="text-xs text-slate-400 mt-1 max-w-xs leading-relaxed">
                        {creationMode === "image-to-image"
                          ? "Upload a photo above, enter your edit instructions, and tap Apply Image Edit."
                          : "Type a description in Hindi or English, choose a style, and tap Generate Image."}
                      </p>
                    </div>
                  )}
                </div>

                {/* Actions below preview: Generate Again & Download Image */}
                {currentImage && (
                  <div className="mt-4 space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={handleGenerateAgain}
                        disabled={isGenerating}
                        className="min-h-[46px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
                      >
                        <RotateCcw className="w-4 h-4" />
                        <span>Generate Again</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownload(currentImage)}
                        className="min-h-[46px] px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download Image</span>
                      </button>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/60 dark:border-slate-800/80 text-xs text-slate-600 dark:text-slate-400">
                      <p className="line-clamp-2 leading-relaxed italic text-[11px]">
                        "{currentImage.prompt}"
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Saved Creations Strip */}
              {recentImages.length > 0 && (
                <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xs">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Saved Creations ({recentImages.length})
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveTab("gallery")}
                      className="text-xs text-teal-600 dark:text-teal-400 hover:underline cursor-pointer"
                    >
                      View All
                    </button>
                  </div>
                  <div className="flex gap-2 overflow-x-auto pb-1 pt-0.5">
                    {recentImages.slice(0, 6).map((img) => (
                      <button
                        key={img.id}
                        type="button"
                        onClick={() => {
                          setCurrentImage(img);
                          setPrompt(img.prompt);
                          setSelectedStyle(img.style);
                          setSelectedAspectRatio(img.aspectRatio);
                          if (img.mode) setCreationMode(img.mode);
                        }}
                        className={`w-14 h-14 shrink-0 rounded-lg overflow-hidden border transition-all cursor-pointer ${
                          currentImage?.id === img.id
                            ? "border-teal-600 ring-2 ring-teal-500/40"
                            : "border-slate-200 dark:border-slate-800 opacity-80 hover:opacity-100"
                        }`}
                        title={img.prompt}
                      >
                        <img
                          src={img.imageUrl}
                          alt={img.prompt}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Fullscreen Image Lightbox Modal */}
      {fullscreenImage && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setFullscreenImage(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh] flex flex-col items-center">
            <button
              type="button"
              onClick={() => setFullscreenImage(null)}
              className="absolute -top-12 right-0 min-h-[44px] min-w-[44px] flex items-center justify-center text-white/80 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={fullscreenImage}
              alt="Fullscreen artwork"
              className="max-h-[85vh] max-w-full rounded-xl object-contain shadow-2xl"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      )}
    </div>
  );
};
