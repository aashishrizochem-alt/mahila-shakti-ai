import React, { useState } from "react";
import {
  Download,
  MessageSquarePlus,
  Trash2,
  X,
  Bookmark,
  ShieldCheck,
  Check,
} from "lucide-react";
import {
  ChatThread,
  RESPONSE_STYLES,
  ResponseStyle,
} from "../types/chat";
import { PWAInstallButton } from "../PWAInstallButton";

interface SessionDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  threads: ChatThread[];
  activeThreadId: string;
  onSelectThread: (threadId: string) => void;
  onNewThread: () => void;
  onDeleteThread: (threadId: string) => void;
  onWipeAllSessions: () => void;
  onExportCurrentThread: () => void;
  responseStyle: ResponseStyle;
  onChangeResponseStyle: (style: ResponseStyle) => void;
  activeTab: "threads" | "saved" | "privacy";
  onChangeTab: (tab: "threads" | "saved" | "privacy") => void;
  onJumpToMessage?: (threadId: string, messageId: string) => void;
  onOpenImageCreator?: () => void;
}

function formatShortTime(ts: number): string {
  try {
    return new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(new Date(ts));
  } catch {
    return "";
  }
}

export const SessionDrawer: React.FC<SessionDrawerProps> = ({
  isOpen,
  onClose,
  threads,
  activeThreadId,
  onSelectThread,
  onNewThread,
  onDeleteThread,
  onWipeAllSessions,
  onExportCurrentThread,
  responseStyle,
  onChangeResponseStyle,
  activeTab,
  onChangeTab,
  onJumpToMessage,
  onOpenImageCreator,
}) => {
  const [confirmWipe, setConfirmWipe] = useState(false);

  const savedMessages = threads.flatMap((t) =>
    t.messages
      .filter((m) => m.pinned && m.role === "model")
      .map((m) => ({
        threadId: t.id,
        threadTitle: t.title,
        message: m,
      }))
  );

  const handleConfirmWipe = () => {
    if (!confirmWipe) {
      setConfirmWipe(true);
      setTimeout(() => setConfirmWipe(false), 4000);
      return;
    }
    setConfirmWipe(false);
    onWipeAllSessions();
    onClose();
  };

  const renderContent = () => (
    <div className="flex flex-col h-full">
      {/* Primary Action: New Private Chat */}
      <div className="p-4 border-b border-slate-200/80 dark:border-slate-800">
        <button
          type="button"
          onClick={() => {
            onNewThread();
            onClose();
          }}
          className="w-full min-h-[48px] px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-teal-600 text-white font-medium text-sm flex items-center justify-center gap-2 shadow-xs hover:bg-slate-800 dark:hover:bg-teal-500 active:scale-[0.98] transition-all whitespace-nowrap cursor-pointer"
        >
          <MessageSquarePlus className="w-4 h-4" />
          <span>New Private Chat</span>
        </button>

        {onOpenImageCreator && (
          <button
            type="button"
            onClick={() => {
              onOpenImageCreator();
              onClose();
            }}
            className="mt-2.5 w-full min-h-[46px] px-4 py-2.5 rounded-xl border border-teal-500/40 bg-teal-50/70 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 hover:bg-teal-100 dark:hover:bg-teal-900/60 font-medium text-sm flex items-center justify-center gap-2 shadow-2xs active:scale-[0.98] transition-all whitespace-nowrap cursor-pointer"
          >
            <span className="text-base">🖼️</span>
            <span className="font-semibold">Image Creator · चित्र निर्माण</span>
          </button>
        )}

        {/* Response Depth / Tone Segmented Selector */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span className="font-medium text-slate-700 dark:text-slate-300">
              Response Style
            </span>
            <span>
              {RESPONSE_STYLES.find((s) => s.id === responseStyle)?.label}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/90 rounded-xl">
            {RESPONSE_STYLES.map((style) => {
              const active = responseStyle === style.id;
              return (
                <button
                  key={style.id}
                  type="button"
                  onClick={() => onChangeResponseStyle(style.id)}
                  className={`min-h-[40px] px-2.5 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                    active
                      ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  {style.label}
                </button>
              );
            })}
          </div>
          <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 leading-snug">
            {RESPONSE_STYLES.find((s) => s.id === responseStyle)?.description}
          </p>
        </div>
      </div>

      {/* Segmented Navigation inside Drawer */}
      <div className="px-4 pt-3 pb-2 border-b border-slate-200/60 dark:border-slate-800/70">
        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-lg">
          <button
            type="button"
            onClick={() => onChangeTab("threads")}
            className={`flex-1 min-h-[38px] px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === "threads"
                ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
            }`}
          >
            Chats ({threads.length})
          </button>
          <button
            type="button"
            onClick={() => onChangeTab("saved")}
            className={`flex-1 min-h-[38px] px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === "saved"
                ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
            }`}
          >
            Saved ({savedMessages.length})
          </button>
          <button
            type="button"
            onClick={() => onChangeTab("privacy")}
            className={`flex-1 min-h-[38px] px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === "privacy"
                ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
            }`}
          >
            Privacy
          </button>
        </div>
      </div>

      {/* Scrollable Body */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1.5">
        {activeTab === "threads" && (
          <>
            {threads.map((thread) => {
              const isSelected = thread.id === activeThreadId;
              const msgCount = thread.messages.length;
              return (
                <div
                  key={thread.id}
                  className={`group flex items-center justify-between rounded-xl px-3 py-2.5 transition-colors ${
                    isSelected
                      ? "bg-slate-200/70 dark:bg-slate-800 text-slate-900 dark:text-white"
                      : "hover:bg-slate-100 dark:hover:bg-slate-800/50 text-slate-700 dark:text-slate-300"
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      onSelectThread(thread.id);
                      onClose();
                    }}
                    className="flex-1 min-w-0 text-left min-h-[44px] flex flex-col justify-center cursor-pointer"
                  >
                    <span className="text-sm font-medium truncate block">
                      {thread.title}
                    </span>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-0.5">
                      <span>
                        {msgCount} {msgCount === 1 ? "msg" : "msgs"}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{formatShortTime(thread.updatedAt)}</span>
                    </div>
                  </button>

                  {threads.length > 1 && (
                    <button
                      type="button"
                      onClick={() => onDeleteThread(thread.id)}
                      className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-400 hover:text-red-600 dark:hover:text-red-400 rounded-lg transition-colors cursor-pointer"
                      aria-label={`Delete conversation ${thread.title}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              );
            })}
          </>
        )}

        {activeTab === "saved" && (
          <>
            {savedMessages.length === 0 ? (
              <div className="py-10 px-4 text-center">
                <Bookmark className="w-6 h-6 text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  No saved responses yet
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                  Tap Save underneath any AI response bubble to keep key answers
                  handy during your session.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {savedMessages.map(({ threadId, threadTitle, message }) => (
                  <button
                    key={message.id}
                    type="button"
                    onClick={() => {
                      onSelectThread(threadId);
                      onJumpToMessage?.(threadId, message.id);
                      onClose();
                    }}
                    className="w-full text-left p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-teal-500/50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                      <span className="truncate max-w-[160px]">{threadTitle}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {formatShortTime(message.timestamp)}
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-300 line-clamp-3 leading-relaxed">
                      {message.text}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </>
        )}

        {activeTab === "privacy" && (
          <div className="p-3 space-y-4 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-slate-900 dark:text-white text-sm mb-1">
                  Persistent On-Device Storage
                </h4>
                <p>
                  Your conversation history is saved securely in your browser&apos;s
                  persistent local storage. Every message is kept directly on your device,
                  surviving page refreshes, browser restarts, and home screen launches.
                  No external accounts or cloud tracking are used.
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200/70 dark:border-slate-800 space-y-1.5">
              <h5 className="font-semibold text-slate-900 dark:text-white">
                Session Controls
              </h5>
              <p>
                You can export your current thread as a clean Markdown file at
                any time or wipe the entire session with one tap below.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Footer Actions: Install PWA, Export & Wipe Session */}
      <div className="p-4 border-t border-slate-200/80 dark:border-slate-800 space-y-2 bg-slate-50/50 dark:bg-slate-900/50">
        <PWAInstallButton className="w-full justify-center min-h-[44px]" isMobileDrawer={true} />

        <button
          type="button"
          onClick={onExportCurrentThread}
          className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 text-xs font-medium flex items-center justify-center gap-2 hover:bg-slate-50 dark:hover:bg-slate-800 active:scale-[0.99] transition-all whitespace-nowrap cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Current Chat (.md)</span>
        </button>

        <button
          type="button"
          onClick={handleConfirmWipe}
          className={`w-full min-h-[44px] px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-center gap-2 active:scale-[0.99] transition-all whitespace-nowrap cursor-pointer ${
            confirmWipe
              ? "bg-red-600 text-white"
              : "text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40"
          }`}
        >
          {confirmWipe ? (
            <>
              <Check className="w-3.5 h-3.5" />
              <span>Tap Again to Permanently Wipe Session</span>
            </>
          ) : (
            <>
              <Trash2 className="w-3.5 h-3.5" />
              <span>Wipe Session History</span>
            </>
          )}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Left Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-80 lg:shrink-0 border-r border-slate-200/80 dark:border-slate-800 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md">
        {renderContent()}
      </aside>

      {/* Mobile / Android Bottom Sheet Drawer */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex flex-col justify-end">
          {/* Scrim */}
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
            onClick={onClose}
            aria-hidden="true"
          />

          {/* Sheet Container */}
          <div className="relative z-10 w-full max-h-[84vh] bg-white dark:bg-slate-900 rounded-t-3xl shadow-2xl border-t border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
            {/* Drag Handle Affordance */}
            <div className="pt-2.5 pb-1 px-4 flex items-center justify-between">
              <div className="w-10" />
              <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full" />
              <button
                type="button"
                onClick={onClose}
                className="min-h-[44px] min-w-[44px] -mr-2 flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                aria-label="Close session menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto">{renderContent()}</div>
          </div>
        </div>
      )}
    </>
  );
};
