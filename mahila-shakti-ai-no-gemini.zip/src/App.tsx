import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  ArrowDown,
  Menu,
  Mic,
  MicOff,
  Moon,
  Plus,
  SendHorizontal,
  Square,
  Sun,
  X,
} from "lucide-react";
import {
  ChatMessage,
  ChatThread,
  RESPONSE_STYLES,
  ResponseStyle,
  STARTER_PROMPTS,
} from "./types/chat";
import { ChatBubble } from "./components/ChatBubble";
import { SessionDrawer } from "./components/SessionDrawer";
import { PWAInstallButton } from "./PWAInstallButton";
import { ImageCreatorView } from "./components/ImageCreator/ImageCreatorView";

import {
  createInitialThread,
  deriveThreadTitle,
  loadInitialThreads,
  loadInitialActiveThreadId,
  loadInitialResponseStyle,
  loadInitialTheme,
  persistThreadsSync,
  persistActiveThreadIdSync,
  persistResponseStyleSync,
  persistThemeSync,
  syncFromIndexedDB,
  clearAllPersistentHistory,
} from "./utils/chatStorage";

export default function App() {
  // Theme state (persisted in localStorage + IndexedDB)
  const [darkMode, setDarkMode] = useState<boolean>(loadInitialTheme);

  // Threads state (persisted in localStorage + IndexedDB)
  const [threads, setThreads] = useState<ChatThread[]>(loadInitialThreads);

  const [activeThreadId, setActiveThreadId] = useState<string>(() => {
    return loadInitialActiveThreadId(threads);
  });

  const [responseStyle, setResponseStyle] = useState<ResponseStyle>(loadInitialResponseStyle);
  const [activeMode, setActiveMode] = useState<"chat" | "image-creator">("chat");
  const [imageCreatorPrompt, setImageCreatorPrompt] = useState<string>("");

  const [inputText, setInputText] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerTab, setDrawerTab] = useState<"threads" | "saved" | "privacy">(
    "threads"
  );
  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(
    null
  );
  const [isListeningMic, setIsListeningMic] = useState(false);

  const chatScrollRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const isGeneratingRef = useRef<boolean>(false);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const recognitionRef = useRef<any>(null);

  const threadsRef = useRef(threads);
  threadsRef.current = threads;

  const activeThread =
    threads.find((t) => t.id === activeThreadId) || threads[0];

  // Sync dark mode class and persistent storage
  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    persistThemeSync(darkMode);
  }, [darkMode]);

  // Keep threads synced to persistent storage
  useEffect(() => {
    persistThreadsSync(threads);
  }, [threads]);

  // Keep activeThreadId synced to persistent storage
  useEffect(() => {
    if (activeThreadId) {
      persistActiveThreadIdSync(activeThreadId);
    }
  }, [activeThreadId]);

  // Sync responseStyle to persistent storage
  useEffect(() => {
    persistResponseStyleSync(responseStyle);
  }, [responseStyle]);

  // Sync from IndexedDB in case it has extra/newer history
  useEffect(() => {
    syncFromIndexedDB().then(({ threads: idbThreads, activeThreadId: idbActiveId }) => {
      if (idbThreads && idbThreads.length > 0) {
        setThreads((current) => {
          const currentTotalMsgs = current.reduce((sum, t) => sum + t.messages.length, 0);
          const idbTotalMsgs = idbThreads.reduce((sum, t) => sum + t.messages.length, 0);
          if (idbTotalMsgs > currentTotalMsgs || idbThreads.length > current.length) {
            persistThreadsSync(idbThreads);
            return idbThreads;
          }
          return current;
        });
        if (idbActiveId) {
          setActiveThreadId((curr) => curr || idbActiveId);
        }
      }
    });
  }, []);

  // Flush threads synchronously before page unload or mobile app switch
  useEffect(() => {
    const handleFlush = () => {
      persistThreadsSync(threadsRef.current);
    };
    window.addEventListener("beforeunload", handleFlush);
    window.addEventListener("pagehide", handleFlush);
    return () => {
      window.removeEventListener("beforeunload", handleFlush);
      window.removeEventListener("pagehide", handleFlush);
    };
  }, []);

  // Auto-resize textarea height cleanly on input change
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    const nextHeight = Math.min(el.scrollHeight, 140);
    el.style.height = `${Math.max(nextHeight, 46)}px`;
  }, [inputText]);

  // Cleanup speechSynthesis on unmount
  useEffect(() => {
    return () => {
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const scrollToBottom = useCallback((behavior: ScrollBehavior = "smooth") => {
    const container = chatScrollRef.current;
    if (!container) return;
    container.scrollTo({
      top: container.scrollHeight,
      behavior,
    });
  }, []);

  const handleScroll = () => {
    const container = chatScrollRef.current;
    if (!container) return;
    const distanceFromBottom =
      container.scrollHeight - container.scrollTop - container.clientHeight;
    setShowScrollBottom(distanceFromBottom > 160);
  };

  // Scroll to bottom when message count increases
  useEffect(() => {
    scrollToBottom("smooth");
  }, [activeThread?.messages.length, scrollToBottom]);

  const updateThreadMessages = useCallback(
    (
      threadId: string,
      updater: (prevMessages: ChatMessage[]) => ChatMessage[],
      newTitle?: string,
      skipPersist = false
    ) => {
      setThreads((prev) => {
        const next = prev.map((t) => {
          if (t.id !== threadId) return t;
          const updatedMessages = updater(t.messages);
          return {
            ...t,
            title: newTitle !== undefined ? newTitle : t.title,
            updatedAt: Date.now(),
            messages: updatedMessages,
          };
        });
        if (!skipPersist) {
          persistThreadsSync(next);
        }
        return next;
      });
    },
    []
  );

  /**
   * Normalizes and windows conversation history for AI inference.
   * - Finds the current user message at the end of the history
   * - Extracts only valid, completed (user, model) historical exchanges preceding it
   * - Excludes interrupted bubbles, rate-limit error messages, and unanswered queries
   * - Limits recent historical exchanges to 3 pairs (6 turns) with bounded length
   *   so multi-turn existing chats never trigger TPM (Tokens Per Minute) rate limits
   * - Preserves the current user query in full without modification
   * - Note: The complete conversation history remains 100% preserved in UI & storage!
   */
  const prepareConversationPayload = useCallback(
    (messages: ChatMessage[]): { role: "user" | "model"; text: string }[] => {
      // Find the last valid user query
      let lastUserIndex = -1;
      for (let i = messages.length - 1; i >= 0; i--) {
        if (
          messages[i].role === "user" &&
          typeof messages[i].text === "string" &&
          messages[i].text.trim().length > 0
        ) {
          lastUserIndex = i;
          break;
        }
      }

      if (lastUserIndex === -1) return [];

      const currentUserText = messages[lastUserIndex].text.trim();
      const historyBefore = messages.slice(0, lastUserIndex);

      // Extract only clean, completed (user, model) pairs from history
      // Drops interrupted errors, placeholder bubbles, and ensures clean turn alternation
      const cleanPairs: { userText: string; modelText: string }[] = [];
      for (let i = 0; i < historyBefore.length - 1; i++) {
        const u = historyBefore[i];
        const m = historyBefore[i + 1];
        if (
          u.role === "user" &&
          m.role === "model" &&
          !m.isError &&
          !m.isStreaming &&
          typeof u.text === "string" &&
          typeof m.text === "string" &&
          u.text.trim().length > 0 &&
          m.text.trim().length > 0 &&
          !m.text.includes("Rate limit reached") &&
          !m.text.includes("Response Interrupted") &&
          !m.text.includes("Failed to connect") &&
          !m.text.includes("high demand")
        ) {
          cleanPairs.push({
            userText: u.text.trim(),
            modelText: m.text.trim(),
          });
          i++; // skip m since it was paired
        }
      }

      // Keep recent 3 completed exchanges (6 turns) to bound tokens comfortably below free tier TPM rate limit
      const windowedPairs = cleanPairs.slice(-3);
      const normalized: { role: "user" | "model"; text: string }[] = [];

      windowedPairs.forEach((pair, idx) => {
        const uText =
          pair.userText.length > 500
            ? `${pair.userText.slice(0, 500)}…`
            : pair.userText;
        const isLatestPair = idx === windowedPairs.length - 1;
        const maxModelChars = isLatestPair ? 1000 : 600;
        const mText =
          pair.modelText.length > maxModelChars
            ? `${pair.modelText.slice(0, maxModelChars)}…`
            : pair.modelText;

        normalized.push({ role: "user", text: uText });
        normalized.push({ role: "model", text: mText });
      });

      // Append current user message in full without truncation
      normalized.push({ role: "user", text: currentUserText });
      return normalized;
    },
    []
  );

  const sendConversationToAI = async (
    threadId: string,
    historyToSend: ChatMessage[],
    assistantMessageId: string,
    style: ResponseStyle
  ) => {
    isGeneratingRef.current = true;
    setIsGenerating(true);
    const controller = new AbortController();
    abortControllerRef.current = controller;

    // Prepare clean, windowed payload that excludes error messages and enforces alternating turns
    const payloadMessages = prepareConversationPayload(historyToSend);
    if (payloadMessages.length === 0) {
      isGeneratingRef.current = false;
      setIsGenerating(false);
      abortControllerRef.current = null;
      return;
    }

    const payload = {
      messages: payloadMessages,
      responseStyle: style,
    };

    let accumulatedText = "";

    try {
      const response = await fetch("/api/chat/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      if (!response.ok || !response.body) {
        const errJson = await response.json().catch(() => null);
        throw new Error(
          errJson?.error || `Server responded with status ${response.status}`
        );
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let buffer = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split("\n\n");
        buffer = events.pop() || "";

        for (const evt of events) {
          const lines = evt.split("\n");
          for (const line of lines) {
            if (line.startsWith("data: ")) {
              const jsonStr = line.slice(6).trim();
              if (!jsonStr) continue;
              const data = JSON.parse(jsonStr);

              if (data.error) {
                throw new Error(data.error);
              }
              if (data.text) {
                accumulatedText += data.text;
                updateThreadMessages(
                  threadId,
                  (msgs) =>
                    msgs.map((m) =>
                      m.id === assistantMessageId
                        ? {
                            ...m,
                            text: accumulatedText,
                            isStreaming: true,
                            isError: false,
                          }
                        : m
                    ),
                  undefined,
                  true // skip persistent disk write on intermediate stream chunks
                );
              }
            }
          }
        }
      }

      updateThreadMessages(
        threadId,
        (msgs) =>
          msgs.map((m) =>
            m.id === assistantMessageId
              ? {
                  ...m,
                  text:
                    accumulatedText ||
                    "I completed the request, though no text was returned. Please try rephrasing your question.",
                  isStreaming: false,
                  isError: false,
                }
              : m
          ),
        undefined,
        false // persist to disk on completion
      );
    } catch (err: unknown) {
      if (err instanceof DOMException && err.name === "AbortError") {
        updateThreadMessages(
          threadId,
          (msgs) =>
            msgs.map((m) =>
              m.id === assistantMessageId
                ? {
                    ...m,
                    text: accumulatedText || "Generation stopped by user.",
                    isStreaming: false,
                    isError: !accumulatedText,
                  }
                : m
            ),
          undefined,
          false
        );
      } else {
        const errMsg =
          err instanceof Error
            ? err.message
            : "Failed to connect to the server. Please try again.";

        updateThreadMessages(
          threadId,
          (msgs) =>
            msgs.map((m) =>
              m.id === assistantMessageId
                ? {
                    ...m,
                    text: errMsg,
                    isStreaming: false,
                    isError: true,
                  }
                : m
            ),
          undefined,
          false
        );
      }
    } finally {
      isGeneratingRef.current = false;
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  const handleSendMessage = async (overrideText?: string) => {
    // If already generating, ignore immediately to prevent duplicate requests
    if (isGeneratingRef.current) return;
    const trimmed = (overrideText !== undefined ? overrideText : inputText).trim();
    if (!trimmed || !activeThread) return;

    // Synchronously set guard to prevent duplicate API requests from double clicks or enter key + form submit
    isGeneratingRef.current = true;
    setIsGenerating(true);

    // Cancel any lingering controller
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }

    if (overrideText === undefined) {
      setInputText("");
    }

    const now = Date.now();
    const userMessage: ChatMessage = {
      id: `user-${now}`,
      role: "user",
      text: trimmed,
      timestamp: now,
    };

    const assistantMessageId = `model-${now + 1}`;
    const placeholderModelMessage: ChatMessage = {
      id: assistantMessageId,
      role: "model",
      text: "",
      timestamp: now + 1,
      isStreaming: true,
      responseStyle,
    };

    const isFirstMessage = activeThread.messages.length === 0;
    const nextTitle = isFirstMessage
      ? deriveThreadTitle(trimmed)
      : undefined;

    // Both new chats and existing chats follow the exact same history accumulation
    const historyForRequest = [...activeThread.messages, userMessage];

    updateThreadMessages(
      activeThread.id,
      (prev) => [...prev, userMessage, placeholderModelMessage],
      nextTitle
    );

    await sendConversationToAI(
      activeThread.id,
      historyForRequest,
      assistantMessageId,
      responseStyle
    );
  };

  const handleStopGenerating = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    isGeneratingRef.current = false;
    setIsGenerating(false);
  };

  const handleRegenerateLast = async () => {
    if (!activeThread) return;

    // Cancel any ongoing in-flight request before retrying
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }

    isGeneratingRef.current = true;
    setIsGenerating(true);

    const messages = activeThread.messages;
    if (messages.length === 0) {
      isGeneratingRef.current = false;
      setIsGenerating(false);
      return;
    }

    // Find last user message
    let lastUserIndex = -1;
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === "user") {
        lastUserIndex = i;
        break;
      }
    }
    if (lastUserIndex === -1) {
      isGeneratingRef.current = false;
      setIsGenerating(false);
      return;
    }

    const historyUpToLastUser = messages.slice(0, lastUserIndex + 1);
    const assistantMessageId = `model-${Date.now()}`;
    const placeholderModelMessage: ChatMessage = {
      id: assistantMessageId,
      role: "model",
      text: "",
      timestamp: Date.now(),
      isStreaming: true,
      responseStyle,
    };

    // Replace the error / incomplete model message with fresh placeholder
    updateThreadMessages(activeThread.id, () => [
      ...historyUpToLastUser,
      placeholderModelMessage,
    ]);

    await sendConversationToAI(
      activeThread.id,
      historyUpToLastUser,
      assistantMessageId,
      responseStyle
    );
  };

  const handleTogglePin = (messageId: string) => {
    if (!activeThread) return;
    updateThreadMessages(activeThread.id, (msgs) =>
      msgs.map((m) => (m.id === messageId ? { ...m, pinned: !m.pinned } : m))
    );
  };

  const handleToggleSpeak = (message: ChatMessage) => {
    if (!("speechSynthesis" in window)) return;
    if (speakingMessageId === message.id) {
      window.speechSynthesis.cancel();
      setSpeakingMessageId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(
      message.text.replace(/[#*`_~]/g, "")
    );
    utterance.onend = () => setSpeakingMessageId(null);
    utterance.onerror = () => setSpeakingMessageId(null);
    setSpeakingMessageId(message.id);
    window.speechSynthesis.speak(utterance);
  };

  const handleNewThread = () => {
    if (activeMode !== "chat") {
      setActiveMode("chat");
    }
    if (isGeneratingRef.current) {
      abortControllerRef.current?.abort();
      abortControllerRef.current = null;
      isGeneratingRef.current = false;
      setIsGenerating(false);
    }
    // If current thread is already empty, just focus input
    if (activeThread && activeThread.messages.length === 0) {
      textareaRef.current?.focus();
      return;
    }
    const fresh = createInitialThread();
    setThreads((prev) => {
      const next = [fresh, ...prev];
      persistThreadsSync(next);
      return next;
    });
    setActiveThreadId(fresh.id);
    persistActiveThreadIdSync(fresh.id);
    setInputText("");
  };

  const handleDeleteThread = (threadId: string) => {
    if (threadId === activeThreadId && isGeneratingRef.current) {
      abortControllerRef.current?.abort();
      abortControllerRef.current = null;
      isGeneratingRef.current = false;
      setIsGenerating(false);
    }
    setThreads((prev) => {
      const filtered = prev.filter((t) => t.id !== threadId);
      if (filtered.length === 0) {
        const fresh = createInitialThread();
        setActiveThreadId(fresh.id);
        persistActiveThreadIdSync(fresh.id);
        persistThreadsSync([fresh]);
        return [fresh];
      }
      if (threadId === activeThreadId) {
        setActiveThreadId(filtered[0].id);
        persistActiveThreadIdSync(filtered[0].id);
      }
      persistThreadsSync(filtered);
      return filtered;
    });
  };

  const handleWipeAllSessions = async () => {
    if (isGenerating) {
      abortControllerRef.current?.abort();
    }
    await clearAllPersistentHistory();
    const fresh = createInitialThread();
    setThreads([fresh]);
    persistThreadsSync([fresh]);
    setActiveThreadId(fresh.id);
    persistActiveThreadIdSync(fresh.id);
    setInputText("");
  };

  const handleExportCurrentThread = () => {
    if (!activeThread) return;
    const lines: string[] = [
      `# ${activeThread.title}`,
      `Exported from Mahila Shakti AI · ${new Date().toLocaleString()}`,
      "",
    ];

    activeThread.messages.forEach((m) => {
      const speaker = m.role === "user" ? "You" : "Mahila Shakti AI";
      lines.push(`### ${speaker}`);
      lines.push(m.text);
      lines.push("");
    });

    const blob = new Blob([lines.join("\n")], {
      type: "text/markdown;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${activeThread.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "mahila-shakti-ai-chat"}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleToggleVoiceInput = () => {
    if (isListeningMic && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListeningMic(false);
      return;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) return;

    const recognition = new SpeechRecognitionAPI();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    recognition.onresult = (event: any) => {
      const transcript = event.results?.[0]?.[0]?.transcript;
      if (transcript) {
        setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
      }
    };

    recognition.onend = () => {
      setIsListeningMic(false);
    };

    recognition.onerror = () => {
      setIsListeningMic(false);
    };

    recognitionRef.current = recognition;
    setIsListeningMic(true);
    recognition.start();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // On desktop, Enter without Shift submits; on mobile virtual keyboards, allow easy newline or Enter submit
    if (e.key === "Enter" && !e.shiftKey && window.innerWidth >= 640) {
      e.preventDefault();
      e.stopPropagation();
      if (!isGeneratingRef.current) {
        handleSendMessage();
      }
    }
  };

  // Find latest model message ID for retry button
  const latestModelMessageId = (() => {
    if (!activeThread) return null;
    for (let i = activeThread.messages.length - 1; i >= 0; i--) {
      if (activeThread.messages[i].role === "model") {
        return activeThread.messages[i].id;
      }
    }
    return null;
  })();

  // Check if Web Speech Recognition is available (e.g., Chrome on Android)
  const supportsSpeechRecognition =
    typeof window !== "undefined" &&
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);

  return (
    <div className="h-dvh w-full flex flex-col bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-hidden">
      {/* Top Bar Contract: Strictly 3 zones (Brand wordmark — Nav links — Primary actions) */}
      <header className="h-14 shrink-0 px-4 sm:px-6 border-b border-slate-200/80 dark:border-slate-800/90 bg-white/85 dark:bg-slate-900/85 backdrop-blur-md flex items-center justify-between z-30">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            scrollToBottom("smooth");
          }}
          className="font-display text-xl font-semibold tracking-tight text-slate-900 dark:text-white whitespace-nowrap"
        >
          Mahila Shakti AI
        </a>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-5 text-sm font-medium text-slate-600 dark:text-slate-400">
          <button
            type="button"
            onClick={() => setActiveMode("chat")}
            className={`py-1 inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
              activeMode === "chat"
                ? "text-slate-900 dark:text-white font-semibold underline underline-offset-8 decoration-teal-600 decoration-2"
                : "hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <span>💬 AI Chat</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveMode("image-creator")}
            className={`py-1 inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
              activeMode === "image-creator"
                ? "text-teal-700 dark:text-teal-300 font-semibold underline underline-offset-8 decoration-teal-600 decoration-2"
                : "hover:text-teal-700 dark:hover:text-teal-300"
            }`}
          >
            <span>🖼️ Image Creator</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveMode("chat");
              setDrawerTab("threads");
              setDrawerOpen(true);
            }}
            className={`py-1 transition-colors whitespace-nowrap cursor-pointer ${
              activeMode === "chat" && drawerTab === "threads"
                ? "hover:text-slate-900 dark:hover:text-white"
                : "hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            Conversations
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveMode("chat");
              setDrawerTab("saved");
              setDrawerOpen(true);
            }}
            className="py-1 hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer"
          >
            Saved Notes
          </button>
          <button
            type="button"
            onClick={handleExportCurrentThread}
            className="py-1 hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer"
          >
            Export Chat
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-1.5">
          {/* Prominent Image Creator button for mobile & desktop */}
          <button
            type="button"
            onClick={() =>
              setActiveMode((prev) => (prev === "image-creator" ? "chat" : "image-creator"))
            }
            className={`min-h-[44px] px-3 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeMode === "image-creator"
                ? "bg-teal-600 text-white shadow-xs"
                : "bg-teal-50 dark:bg-teal-950/50 text-teal-800 dark:text-teal-300 hover:bg-teal-100 dark:hover:bg-teal-900/60 border border-teal-500/30"
            }`}
            aria-label="Toggle Image Creator mode"
          >
            <span>🖼️</span>
            <span>{activeMode === "image-creator" ? "💬 Chat" : "Image Creator"}</span>
          </button>

          <button
            type="button"
            onClick={() => setDarkMode((d) => !d)}
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label={darkMode ? "Switch to light theme" : "Switch to dark theme"}
          >
            {darkMode ? (
              <Sun className="w-5 h-5" />
            ) : (
              <Moon className="w-5 h-5" />
            )}
          </button>

          <PWAInstallButton className="hidden sm:inline-flex min-h-[44px]" />

          <button
            type="button"
            onClick={handleNewThread}
            className="min-h-[44px] px-3.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700 text-slate-900 dark:text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
            aria-label="Start new conversation"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden xs:inline">New Chat</span>
          </button>

          <button
            type="button"
            onClick={() => setDrawerOpen(true)}
            className="lg:hidden min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Open session history and settings"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Workspace Container */}
      <div className="flex-1 flex min-h-0 relative">
        {/* Session Drawer */}
        <SessionDrawer
          isOpen={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          threads={threads}
          activeThreadId={activeThread?.id || ""}
          onSelectThread={(id) => {
            if (id !== activeThreadId && isGeneratingRef.current) {
              abortControllerRef.current?.abort();
              abortControllerRef.current = null;
              isGeneratingRef.current = false;
              setIsGenerating(false);
            }
            setActiveThreadId(id);
            persistActiveThreadIdSync(id);
            setActiveMode("chat");
          }}
          onNewThread={() => {
            handleNewThread();
            setActiveMode("chat");
          }}
          onDeleteThread={handleDeleteThread}
          onWipeAllSessions={handleWipeAllSessions}
          onExportCurrentThread={handleExportCurrentThread}
          responseStyle={responseStyle}
          onChangeResponseStyle={setResponseStyle}
          activeTab={drawerTab}
          onChangeTab={setDrawerTab}
          onOpenImageCreator={() => setActiveMode("image-creator")}
        />

        {activeMode === "image-creator" ? (
          <ImageCreatorView
            onBackToChat={() => setActiveMode("chat")}
            initialPrompt={imageCreatorPrompt}
          />
        ) : (
          /* Center Chat Column */
          <main className="flex-1 flex flex-col min-w-0 min-h-0 relative">
          {/* Scrollable Conversation Feed */}
          <div
            ref={chatScrollRef}
            onScroll={handleScroll}
            className="flex-1 overflow-y-auto px-4 sm:px-6 md:px-10 py-5"
          >
            <div className="max-w-3xl mx-auto">
              {activeThread && activeThread.messages.length === 0 ? (
                /* Empty Session / New Thread Welcome Canvas */
                <div className="py-4 sm:py-10 space-y-7">
                  <div className="space-y-2.5">
                    <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
                      <span>Private Session</span>
                      <span aria-hidden="true">·</span>
                      <span>Ephemeral History</span>
                      <span aria-hidden="true">·</span>
                      <span>Natural-Language AI</span>
                    </div>
                    <h1
                      className="font-display text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-white tracking-tight"
                      style={{ textWrap: "balance" }}
                    >
                      What would you like to explore today?
                    </h1>
                    <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 max-w-xl leading-relaxed">
                      Type any question, topic, or draft below for a detailed
                      response. Your conversation stays in your current browser
                      session and clears when you close or wipe the session.
                    </p>
                  </div>

                  {/* Mobile-Accessible Response Style Selector */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                      <span>Response depth</span>
                      <span className="font-medium text-slate-700 dark:text-slate-300">
                        {
                          RESPONSE_STYLES.find((s) => s.id === responseStyle)
                            ?.description
                        }
                      </span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl border border-slate-200/80 dark:border-slate-800">
                      {RESPONSE_STYLES.map((style) => {
                        const isSelected = responseStyle === style.id;
                        return (
                          <button
                            key={style.id}
                            type="button"
                            onClick={() => setResponseStyle(style.id)}
                            className={`min-h-[44px] px-3 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                              isSelected
                                ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs"
                                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                            }`}
                          >
                            {style.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Starter Prompt Cards (Generous Touch Targets for Android) */}
                  <div className="space-y-2.5">
                    <h2 className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      Suggested conversation starters
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {STARTER_PROMPTS.map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => handleSendMessage(item.prompt)}
                          className="text-left p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-teal-600/60 dark:hover:border-teal-500/60 active:scale-[0.99] transition-all flex flex-col justify-between min-h-[84px] cursor-pointer"
                        >
                          <div className="text-xs text-teal-700 dark:text-teal-400 font-medium mb-1">
                            {item.category}
                          </div>
                          <div className="text-sm font-semibold text-slate-900 dark:text-white leading-snug">
                            {item.title}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                /* Conversation Chat Bubbles List */
                <div className="space-y-5 pb-4">
                  {activeThread?.messages.map((msg) => (
                    <div key={msg.id} id={`msg-${msg.id}`}>
                      <ChatBubble
                        message={msg}
                        isLatestModelMessage={msg.id === latestModelMessageId}
                        onTogglePin={handleTogglePin}
                        onRegenerate={handleRegenerateLast}
                        onReusePrompt={(text) => {
                          setInputText(text);
                          textareaRef.current?.focus();
                        }}
                        speakingMessageId={speakingMessageId}
                        onToggleSpeak={handleToggleSpeak}
                        onOpenImageCreatorWithPrompt={(p) => {
                          setImageCreatorPrompt(p);
                          setActiveMode("image-creator");
                        }}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Floating Scroll-to-Bottom Button */}
          {showScrollBottom && (
            <button
              type="button"
              onClick={() => scrollToBottom("smooth")}
              className="absolute bottom-24 right-5 z-20 min-h-[44px] min-w-[44px] rounded-full bg-slate-900/90 dark:bg-slate-800 text-white shadow-lg border border-slate-700 flex items-center justify-center hover:bg-slate-800 active:scale-95 transition-all cursor-pointer"
              aria-label="Scroll to latest message"
            >
              <ArrowDown className="w-4 h-4" />
            </button>
          )}

          {/* Bottom Composer Bar (Ergonomic Natural Thumb Zone for Android) */}
          <div className="shrink-0 px-3 sm:px-6 pt-2 pb-3 sm:pb-4 bg-gradient-to-t from-[#F8FAFC] via-[#F8FAFC] to-transparent dark:from-slate-950 dark:via-slate-950">
            <div className="max-w-3xl mx-auto">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendMessage();
                }}
                className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-300/90 dark:border-slate-700/90 focus-within:border-teal-600 dark:focus-within:border-teal-500 shadow-sm transition-colors p-2 flex items-end gap-2"
              >
                {/* Textarea Input */}
                <div className="flex-1 min-w-0 relative flex items-center">
                  <textarea
                    ref={textareaRef}
                    rows={1}
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={handleKeyDown}
                    enterKeyHint="send"
                    placeholder="Type a message..."
                    aria-label="Message input"
                    className="w-full resize-none bg-transparent px-3 py-2.5 text-[15px] leading-snug text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none max-h-[140px]"
                  />

                  {inputText.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        setInputText("");
                        textareaRef.current?.focus();
                      }}
                      className="min-h-[40px] min-w-[40px] flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg shrink-0 cursor-pointer"
                      aria-label="Clear text input"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Optional Voice Dictation Button on Supported Browsers (e.g. Android Chrome) */}
                {supportsSpeechRecognition && (
                  <button
                    type="button"
                    onClick={handleToggleVoiceInput}
                    className={`min-h-[48px] min-w-[48px] rounded-xl flex items-center justify-center shrink-0 transition-colors cursor-pointer ${
                      isListeningMic
                        ? "bg-red-600 text-white animate-pulse"
                        : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                    }`}
                    aria-label={
                      isListeningMic ? "Stop voice input" : "Start voice input"
                    }
                    title={
                      isListeningMic ? "Listening... Tap to stop" : "Voice dictation"
                    }
                  >
                    {isListeningMic ? (
                      <MicOff className="w-5 h-5" />
                    ) : (
                      <Mic className="w-5 h-5" />
                    )}
                  </button>
                )}

                {/* Primary Send / Stop Button (48px height, clear label + icon for mobile thumb tap) */}
                {isGenerating ? (
                  <button
                    type="button"
                    onClick={handleStopGenerating}
                    className="min-h-[48px] px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm inline-flex items-center justify-center gap-2 shrink-0 active:scale-[0.98] transition-all whitespace-nowrap cursor-pointer"
                    aria-label="Stop generating response"
                  >
                    <Square className="w-4 h-4 fill-current" />
                    <span>Stop</span>
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={!inputText.trim()}
                    className="min-h-[48px] px-5 rounded-xl bg-slate-900 dark:bg-teal-600 hover:bg-slate-800 dark:hover:bg-teal-500 disabled:bg-slate-200 dark:disabled:bg-slate-800 disabled:text-slate-400 dark:disabled:text-slate-600 text-white font-semibold text-sm inline-flex items-center justify-center gap-2 shrink-0 active:scale-[0.98] transition-all whitespace-nowrap cursor-pointer disabled:cursor-not-allowed"
                    aria-label="Send message"
                  >
                    <span>Send</span>
                    <SendHorizontal className="w-4 h-4" />
                  </button>
                )}
              </form>

              {/* Quiet unboxed status line underneath input */}
              <div className="mt-1.5 px-2 flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500">
                <div className="flex items-center gap-1.5 truncate">
                  <span>Mode: {RESPONSE_STYLES.find((s) => s.id === responseStyle)?.label}</span>
                  <span aria-hidden="true">·</span>
                  <span>Session history active</span>
                </div>
                <span className="hidden sm:inline">
                  Press Enter to send, Shift + Enter for new line
                </span>
              </div>
            </div>
          </div>
        </main>
      )}
    </div>
  </div>
  );
}
