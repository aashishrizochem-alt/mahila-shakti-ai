import {
  ImageGenerationRequest,
  ImageGenerationResponse,
  ImageProviderConfig,
  ImageToImageProvider,
} from "../types.js";
import { PromptEngineer } from "../promptEngineer.js";

/**
 * Pluggable Image-to-Image / Reference Image Provider.
 * Allows plugging in any OpenAI-compatible / Stability / Fal / Replicate or custom
 * image-to-image API endpoint via environment variables:
 * - IMG2IMG_API_ENDPOINT
 * - IMG2IMG_API_KEY
 *
 * When no external provider credentials are configured, it validates the request,
 * parses the structured edit instructions, and returns the clear error specified in the prompt:
 * "Reference-image generation is not available with the current free backend."
 */
export class PluggableImg2ImgProvider implements ImageToImageProvider {
  id = "compatible-img2img";
  supportsImageToImage = true as const;

  getConfig(): ImageProviderConfig {
    const hasEndpoint = Boolean(process.env.IMG2IMG_API_ENDPOINT);
    const hasApiKey = Boolean(process.env.IMG2IMG_API_KEY);
    const isConfigured = hasEndpoint && hasApiKey;

    return {
      id: this.id,
      name: "Compatible Reference-Guided Image-to-Image Engine",
      description:
        "High-fidelity image edit provider that processes reference images and instruction prompts.",
      isPaid: true,
      requiresApiKey: true,
      supportsImageToImage: true,
      capabilities: {
        textToImage: true,
        imageToImage: true,
        supportedMimeTypes: ["image/jpeg", "image/png", "image/webp"],
        maxImageSizeMB: 10,
        requiresApiKey: true,
      },
      limitsNotice: isConfigured
        ? "Connected to configured image-to-image backend."
        : "Requires IMG2IMG_API_ENDPOINT and IMG2IMG_API_KEY to execute reference edits.",
    };
  }

  async editImage(
    req: ImageGenerationRequest & { referenceImage: string }
  ): Promise<ImageGenerationResponse> {
    return this.generateImage(req);
  }

  async generateImage(
    req: ImageGenerationRequest
  ): Promise<ImageGenerationResponse> {
    const rawPrompt = (req.prompt || "").trim();
    if (!rawPrompt) {
      throw new Error("Prompt is required for image generation.");
    }

    const endpoint = process.env.IMG2IMG_API_ENDPOINT;
    const apiKey = process.env.IMG2IMG_API_KEY;

    // Validate structured prompt extraction
    const structured = PromptEngineer.parsePrompt(
      rawPrompt,
      req.style || "realistic",
      "image-to-image",
      req.aspectRatio || "1:1",
      Boolean(req.referenceImage)
    );

    // If an external img2img endpoint is configured:
    if (endpoint && apiKey) {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          prompt: structured.finalDiffusionPrompt,
          image: req.referenceImage,
          seed: req.seed,
          aspectRatio: req.aspectRatio,
        }),
      });

      if (!response.ok) {
        throw new Error(
          `Image-to-image provider failed with status ${response.status}: ${response.statusText}`
        );
      }

      const result = await response.json();
      return {
        success: true,
        imageUrl: result.imageUrl || result.data?.[0]?.url || result.image,
        prompt: rawPrompt,
        structuredPrompt: structured,
        mode: "image-to-image",
        style: req.style,
        aspectRatio: req.aspectRatio,
        seed: req.seed || 0,
        provider: this.id,
        width: 512,
        height: 512,
      };
    }

    // When the free backend is in use without an img2img provider configured:
    throw new Error(
      "Reference-image generation is not available with the current free backend. " +
        "The free community cluster supports text-to-image generation only. " +
        "To enable image-to-image editing, a compatible image-to-image provider or API key is required."
    );
  }
}
