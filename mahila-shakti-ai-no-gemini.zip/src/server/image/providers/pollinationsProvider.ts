import {
  AspectRatio,
  ImageGenerationRequest,
  ImageGenerationResponse,
  ImageProvider,
  ImageProviderConfig,
} from "../types.js";
import { PromptEngineer } from "../promptEngineer.js";

const ASPECT_RATIO_DIMENSIONS: Record<
  AspectRatio,
  { width: number; height: number }
> = {
  "1:1": { width: 512, height: 512 },
  "4:5": { width: 512, height: 640 },
  "16:9": { width: 768, height: 432 },
  "9:16": { width: 432, height: 768 },
};

export class PollinationsProvider implements ImageProvider {
  id = "pollinations-free";

  getConfig(): ImageProviderConfig {
    const hasApiKey = Boolean(process.env.POLLINATIONS_API_KEY);
    return {
      id: this.id,
      name: "Pollinations Community Diffusion (SDXL / Sana / DreamShaper)",
      description:
        "Free and open community-powered diffusion models for text-to-image generation.",
      isPaid: false,
      requiresApiKey: false,
      // The public free endpoint is text-to-image only; img2img is not supported on the free community cluster
      supportsImageToImage: false,
      capabilities: {
        textToImage: true,
        imageToImage: false,
        supportedMimeTypes: ["image/jpeg", "image/png", "image/webp"],
        maxImageSizeMB: 5,
        requiresApiKey: false,
      },
      limitsNotice:
        "Free tier powered by community GPU nodes. High-quality text-to-image is supported without cost.",
    };
  }

  async generateImage(
    req: ImageGenerationRequest
  ): Promise<ImageGenerationResponse> {
    const rawPrompt = (req.prompt || "").replace(/[\r\n]+/g, " ").trim();
    if (!rawPrompt) {
      throw new Error("Prompt is required for image generation.");
    }

    const mode = req.mode || (req.referenceImage ? "image-to-image" : "text-to-image");

    // PROBLEM 1 REQUIREMENT:
    // If user uploaded a reference image or requested image-to-image edit:
    // Do NOT silently ignore the reference image.
    // Do NOT generate an unrelated image.
    // Report clearly that reference-image generation is not available with the current free backend.
    if (mode === "image-to-image" || Boolean(req.referenceImage)) {
      throw new Error(
        "Reference-image generation is not available with the current free backend. " +
          "The free community cluster supports text-to-image generation only. " +
          "To enable image-to-image editing, a compatible image-to-image provider or API key is required."
      );
    }

    const style = req.style || "realistic";
    const aspectRatio = req.aspectRatio || "1:1";
    const dimensions =
      ASPECT_RATIO_DIMENSIONS[aspectRatio] || ASPECT_RATIO_DIMENSIONS["1:1"];

    // PROBLEM 2: Engineer structured internal prompt from user instructions
    // Preserves subject, gender, clothing, saree colour, blouse colour, jewellery,
    // hairstyle, pose, body proportions, background, lighting, and style without rewriting.
    const structured = PromptEngineer.parsePrompt(
      rawPrompt,
      style,
      mode,
      aspectRatio,
      false
    );

    const seed =
      typeof req.seed === "number" && !isNaN(req.seed)
        ? req.seed
        : Math.floor(Math.random() * 1000000);

    const encodedPrompt = encodeURIComponent(structured.finalDiffusionPrompt);

    const apiKey = process.env.POLLINATIONS_API_KEY || "";
    const headers: Record<string, string> = {
      Accept: "image/jpeg,image/png,image/*",
      "User-Agent": "MahilaShaktiAI-ImageCreator/1.0",
    };
    if (apiKey) {
      headers["Authorization"] = `Bearer ${apiKey}`;
    }

    const encodedExpanded = encodeURIComponent(structured.finalDiffusionPrompt);
    const encodedRaw = encodeURIComponent(rawPrompt);

    // Ordered endpoint candidates: Do NOT append nologo=true without apiKey,
    // as nologo=true triggers HTTP 402 on the free community cluster.
    const logoParam = apiKey ? "&nologo=true" : "";
    const endpointCandidates = [
      `https://image.pollinations.ai/prompt/${encodedExpanded}?model=dreamshaper`,
      `https://image.pollinations.ai/prompt/${encodedExpanded}?model=sana`,
      `https://image.pollinations.ai/prompt/${encodedExpanded}`,
      `https://image.pollinations.ai/prompt/${encodedRaw}?model=dreamshaper`,
      `https://image.pollinations.ai/prompt/${encodedRaw}?model=sana`,
      `https://image.pollinations.ai/prompt/${encodedRaw}`,
      `https://image.pollinations.ai/prompt/${encodedExpanded}?width=${dimensions.width}&height=${dimensions.height}&seed=${seed}${logoParam}`,
      `https://image.pollinations.ai/prompt/${encodedRaw}?width=${dimensions.width}&height=${dimensions.height}&seed=${seed}${logoParam}`,
    ];

    let lastError: Error | null = null;

    for (const url of endpointCandidates) {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 35000);

      try {
        const response = await fetch(url, {
          headers,
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          if (response.status === 402) {
            throw new Error(
              "Community image generation engine reached rate limits (HTTP 402). Please retry in a moment, or configure POLLINATIONS_API_KEY in environment variables."
            );
          }
          throw new Error(
            `Image engine returned HTTP ${response.status} (${response.statusText})`
          );
        }

        const contentType = (response.headers.get("content-type") || "").toLowerCase();
        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);

        // Strict verification: response MUST be an image, NEVER JSON or HTML!
        if (!contentType.startsWith("image/") && !contentType.includes("octet-stream")) {
          const rawText = buffer.toString("utf-8");
          let errMsg = "Image service returned non-image response.";
          try {
            const parsed = JSON.parse(rawText);
            errMsg = parsed.message || parsed.error || errMsg;
          } catch {
            if (rawText.length < 200) errMsg = rawText;
          }
          throw new Error(errMsg);
        }

        if (buffer.length < 500) {
          throw new Error("Received truncated or invalid image data.");
        }

        const validContentType = contentType.startsWith("image/")
          ? contentType
          : "image/jpeg";
        const base64Data = buffer.toString("base64");
        const dataUrl = `data:${validContentType};base64,${base64Data}`;

        return {
          success: true,
          imageUrl: dataUrl,
          prompt: rawPrompt,
          structuredPrompt: structured,
          mode,
          style,
          aspectRatio,
          seed,
          provider: this.id,
          width: dimensions.width,
          height: dimensions.height,
        };
      } catch (err: unknown) {
        clearTimeout(timeoutId);
        lastError = err instanceof Error ? err : new Error(String(err));
        console.warn(`Endpoint candidate failed (${url.slice(0, 60)}...):`, lastError.message);
      }
    }

    throw lastError || new Error("Failed to generate image from available free engines.");
  }
}
