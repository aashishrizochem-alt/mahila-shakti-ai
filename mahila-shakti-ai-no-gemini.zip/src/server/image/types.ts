export type ImageStyle =
  | "realistic"
  | "cinematic"
  | "portrait"
  | "fantasy"
  | "illustration"
  | "painting"
  | "cartoon"
  | "poster";

export type AspectRatio = "1:1" | "4:5" | "16:9" | "9:16";

export type ImageCreationMode = "text-to-image" | "image-to-image";

export interface StructuredVisualPrompt {
  subject: string;
  gender?: string;
  clothing?: string;
  sareeColor?: string;
  blouseColor?: string;
  jewelry?: string;
  hairstyle?: string;
  pose?: string;
  bodyProportions?: string;
  facialFeatures?: string;
  background?: string;
  cameraAngle?: string;
  lighting?: string;
  environment?: string;
  imageStyle?: string;
  aspectRatio?: AspectRatio;
  requestedComposition?: string;
  isImageEdit?: boolean;
  preservedElements?: string[];
  requestedModifications?: string[];
  finalDiffusionPrompt: string;
}

export interface ImageGenerationRequest {
  prompt: string;
  mode?: ImageCreationMode;
  style: ImageStyle;
  aspectRatio: AspectRatio;
  referenceImage?: string; // base64 or data URL for image-to-image
  referenceImageName?: string;
  seed?: number;
}

export interface ImageGenerationResponse {
  success: boolean;
  imageUrl?: string;
  prompt: string;
  structuredPrompt?: StructuredVisualPrompt;
  mode?: ImageCreationMode;
  style: ImageStyle;
  aspectRatio: AspectRatio;
  seed: number;
  provider: string;
  width: number;
  height: number;
  error?: string;
}

export interface ImageProviderCapabilities {
  textToImage: boolean;
  imageToImage: boolean;
  supportedMimeTypes: string[];
  maxImageSizeMB: number;
  requiresApiKey: boolean;
}

export interface ImageProviderConfig {
  id: string;
  name: string;
  description: string;
  isPaid: boolean;
  requiresApiKey: boolean;
  supportsImageToImage: boolean;
  capabilities: ImageProviderCapabilities;
  limitsNotice: string;
}

export interface ImageProvider {
  id: string;
  getConfig(): ImageProviderConfig;
  generateImage(req: ImageGenerationRequest): Promise<ImageGenerationResponse>;
}

export interface ImageToImageProvider extends ImageProvider {
  supportsImageToImage: true;
  editImage(
    req: ImageGenerationRequest & { referenceImage: string }
  ): Promise<ImageGenerationResponse>;
}
