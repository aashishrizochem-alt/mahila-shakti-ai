import express, { Request, Response } from "express";
import {
  ImageGenerationRequest,
  ImageProvider,
  ImageProviderConfig,
} from "./types.js";
import { PollinationsProvider } from "./providers/pollinationsProvider.js";
import { PluggableImg2ImgProvider } from "./providers/pluggableImg2ImgProvider.js";

class ImageGenerationManager {
  private providers: Map<string, ImageProvider> = new Map();
  private activeProviderId = "pollinations-free";

  constructor() {
    const defaultProvider = new PollinationsProvider();
    this.registerProvider(defaultProvider);

    const img2imgProvider = new PluggableImg2ImgProvider();
    this.registerProvider(img2imgProvider);

    // If environment has img2img backend configured, make it available
    if (process.env.IMG2IMG_API_ENDPOINT && process.env.IMG2IMG_API_KEY) {
      console.log("Configured custom image-to-image provider active.");
    }
  }

  registerProvider(provider: ImageProvider) {
    this.providers.set(provider.id, provider);
  }

  getActiveProvider(): ImageProvider {
    const provider = this.providers.get(this.activeProviderId);
    if (!provider) {
      throw new Error(`Active provider '${this.activeProviderId}' not found.`);
    }
    return provider;
  }

  getImg2ImgProvider(): ImageProvider {
    return (
      this.providers.get("compatible-img2img") ||
      this.getActiveProvider()
    );
  }

  getAllConfigs(): ImageProviderConfig[] {
    return Array.from(this.providers.values()).map((p) => p.getConfig());
  }

  setActiveProvider(id: string) {
    if (!this.providers.has(id)) {
      throw new Error(`Provider '${id}' is not registered.`);
    }
    this.activeProviderId = id;
  }
}

export const imageManager = new ImageGenerationManager();

export function registerImageRoutes(app: express.Express) {
  // Get image generation engine status & limits config
  app.get("/api/image/config", (_req: Request, res: Response) => {
    try {
      const activeProvider = imageManager.getActiveProvider();
      res.json({
        activeProvider: activeProvider.getConfig(),
        availableProviders: imageManager.getAllConfigs(),
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to load config";
      res.status(500).json({ error: msg });
    }
  });

  // Generate Image endpoint
  app.post("/api/image/generate", async (req: Request, res: Response) => {
    const body = req.body as ImageGenerationRequest;
    const prompt = (body?.prompt || "").trim();

    if (!prompt) {
      res.status(400).json({
        error: "Prompt cannot be empty. Please enter an image description in Hindi or English.",
      });
      return;
    }

    const mode =
      body.mode || (body.referenceImage ? "image-to-image" : "text-to-image");

    try {
      // If image-to-image mode is requested with an image, use the img2img provider interface
      const provider =
        mode === "image-to-image" || Boolean(body.referenceImage)
          ? imageManager.getImg2ImgProvider()
          : imageManager.getActiveProvider();

      const result = await provider.generateImage({
        prompt,
        mode,
        style: body.style || "realistic",
        aspectRatio: body.aspectRatio || "1:1",
        referenceImage: body.referenceImage,
        referenceImageName: body.referenceImageName,
        seed: body.seed,
      });

      res.json(result);
    } catch (err: unknown) {
      console.warn("Image generation / edit returned notice:", err instanceof Error ? err.message : err);
      const msg =
        err instanceof Error
          ? err.message
          : "An unexpected error occurred during image generation.";
      res.status(400).json({ error: msg });
    }
  });
}
