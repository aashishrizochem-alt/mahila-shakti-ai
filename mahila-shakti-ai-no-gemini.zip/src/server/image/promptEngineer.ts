import { AspectRatio, ImageCreationMode, ImageStyle, StructuredVisualPrompt } from "./types.js";

// Helper to find match in text using dictionary with keys sorted by length descending
function findLongestMatch(
  text: string,
  dict: Record<string, string>,
  excludeCheck?: (matchedKey: string, index: number, fullText: string) => boolean
): { matchedKey: string; englishValue: string } | null {
  const lowerText = text.toLowerCase();
  const sortedKeys = Object.keys(dict).sort((a, b) => b.length - a.length);

  for (const key of sortedKeys) {
    const keyLower = key.toLowerCase();
    const idx = lowerText.indexOf(keyLower);
    if (idx !== -1) {
      if (excludeCheck && excludeCheck(key, idx, text)) {
        continue;
      }
      return { matchedKey: key, englishValue: dict[key] };
    }
  }
  return null;
}

// Comprehensive bilingual color mapping
// Crucial: "गहरा" (deep/dark) must NOT match "हरा" (green)
const COLOR_MAP: Record<string, string> = {
  // Compound / Multi-color Hindi
  "हरे और गुलाबी": "emerald green and vibrant pink",
  "हरा और गुलाबी": "emerald green and vibrant pink",
  "गुलाबी और हरा": "vibrant pink and emerald green",
  "लाल और सुनहरा": "crimson red and golden",
  "नीला और सुनहरा": "royal blue and golden",
  "गहरा गुलाबी": "deep magenta pink",
  "गहरे गुलाबी": "deep magenta pink",
  "गहरी गुलाबी": "deep magenta pink",
  "हल्का गुलाबी": "soft pastel light pink",
  "हल्के गुलाबी": "soft pastel light pink",
  "गहरा लाल": "deep crimson maroon red",
  "गहरे लाल": "deep crimson maroon red",
  "गहरा नीला": "deep royal navy blue",
  "गहरे नीले": "deep royal navy blue",
  "गहरा हरा": "deep emerald forest green",
  "गहरे हरे": "deep emerald forest green",
  "गहरी हरी": "deep emerald forest green",
  "हल्का हरा": "light mint sage green",
  "हल्का नीला": "light sky blue",
  "नींबू पीला": "bright lemon yellow",

  // Single Hindi colors
  "गुलाबी": "vibrant pink",
  "लाल": "crimson red",
  "नीला": "royal blue",
  "नीले": "royal blue",
  "नीली": "royal blue",
  "पीला": "golden yellow",
  "पीले": "golden yellow",
  "पीली": "golden yellow",
  "हरा": "emerald green",
  "हरे": "emerald green",
  "हरी": "emerald green",
  "सफेद": "pristine white",
  "सफ़ेद": "pristine white",
  "काला": "jet black",
  "काले": "jet black",
  "काली": "jet black",
  "बैंगनी": "royal violet purple",
  "नारंगी": "marigold orange",
  "केसरिया": "saffron orange",
  "सुनहरा": "shimmering golden",
  "सुनहरे": "shimmering golden",
  "सुनहरी": "shimmering golden",
  "चांदी": "silver",
  "मैजेंटा": "magenta",
  "मैरून": "maroon",
  "जामुनी": "deep purple plum",
  "फिरोजी": "turquoise cyan",

  // English compound & single colors
  "deep magenta pink": "deep magenta pink",
  "dark magenta pink": "deep magenta pink",
  "deep pink": "deep magenta pink",
  "dark pink": "deep magenta pink",
  "light pink": "soft pastel pink",
  "hot pink": "hot vibrant pink",
  "green and pink": "emerald green and vibrant pink",
  "pink and green": "emerald green and vibrant pink",
  "emerald green": "emerald green",
  "dark green": "deep forest green",
  "light green": "soft mint green",
  "royal blue": "royal blue",
  "navy blue": "deep navy blue",
  "sky blue": "soft sky blue",
  "crimson red": "crimson red",
  "ruby red": "ruby red",
  "golden yellow": "golden yellow",
  "mustard yellow": "rich mustard yellow",
  "bright yellow": "radiant yellow",
  "marigold orange": "marigold orange",
  "saffron": "saffron orange",
  "magenta": "magenta",
  "maroon": "deep maroon",
  "purple": "royal purple",
  "golden": "shimmering golden",
  "gold": "shimmering gold",
  "silver": "lustrous silver",
  "white": "pristine white",
  "black": "elegant black",
  "pink": "vibrant pink",
  "green": "emerald green",
  "blue": "royal blue",
  "red": "crimson red",
  "yellow": "golden yellow",
};

// Check if matched color key "हरा" is actually an unintentional substring of "गहरा"
function isSubstringOfGahara(key: string, idx: number, text: string): boolean {
  if (key === "हरा" || key === "हरे" || key === "हरी") {
    if (idx > 0 && text[idx - 1] === "ग") {
      return true; // Preceded by 'ग', meaning 'गहरा'
    }
  }
  return false;
}

const CLOTHING_MAP: Record<string, string> = {
  // Hindi
  "कढ़ाईदार साड़ी": "intricately embroidered saree with fine zari border",
  "कढ़ाई वाली साड़ी": "intricately embroidered saree with fine zari work",
  "जरीदार साड़ी": "traditional saree embellished with golden zari work",
  "बनारसी साड़ी": "luxurious Banarasi silk saree with ornate floral brocade",
  "कांचीपुरम साड़ी": "rich Kanchipuram silk saree with grand golden border",
  "चंदेरी साड़ी": "delicate lightweight Chanderi saree",
  "रेशमी साड़ी": "pure Banarasi silk saree with lustrous drape",
  "सिल्क साड़ी": "elegant pure silk saree with regal drape",
  "कॉटन साड़ी": "handloom crisp cotton saree",
  "साड़ी": "traditional Indian saree",
  "साड़ी": "traditional Indian saree",
  "लहंगा चोली": "traditional royal lehenga choli with heavy ornate embroidery",
  "लहंगा": "traditional royal lehenga choli with ornate embroidery",
  "सलवार सूट": "traditional elegant salwar kameez suit with dupatta",
  "अनारकली सूट": "flowing royal Anarkali suit with flared silhouette",
  "कुर्ती": "graceful Indian ethnic kurti",
  "दुपट्टा": "flowing sheer dupatta scarf with golden tassels",
  "ब्लाउज": "tailored traditional blouse",
  "परिधान": "traditional Indian ethnic attire",
  "पोशाक": "traditional Indian ethnic dress",

  // English
  "embroidered saree": "intricately embroidered saree with fine zari work",
  "banarasi saree": "luxurious Banarasi silk saree with ornate gold zari",
  "silk saree": "pure silk saree with lustrous drape and rich pallu",
  "saree": "traditional Indian saree",
  "sari": "traditional Indian saree",
  "lehenga choli": "ornate festive lehenga choli with rich embroidery",
  "lehenga": "ornate festive lehenga choli",
  "salwar kameez": "traditional elegant salwar kameez",
  "anarkali": "flowing royal anarkali suit",
  "ethnic dress": "traditional Indian ethnic attire",
};

const JEWELRY_MAP: Record<string, string> = {
  // Hindi
  "पारंपरिक सोने के आभूषण": "traditional handcrafted 22k gold jewelry set",
  "पारंपरिक आभूषण": "traditional Indian gold jewelry including necklace and jhumkas",
  "पारंपरिक गहने": "traditional gold jewelry including necklaces and bangles",
  "सोने के गहने": "shimmering yellow gold jewelry set",
  "कुंदन आभूषण": "regal Kundan and Meenakari heritage jewelry set",
  "आभूषण": "traditional Indian jewelry, gold jhumka earrings and necklace",
  "गहने": "traditional Indian gold jewelry and bangles",
  "झुमके": "intricate gold jhumka chandelier earrings",
  "झुमका": "intricate gold jhumka chandelier earrings",
  "हार": "regal layered gold necklace",
  "गले का हार": "regal gold necklace choker",
  "चूड़ियां": "traditional glass and ornate gold bangles",
  "चूड़ियाँ": "traditional glass and ornate gold bangles",
  "कंगन": "carved gold kadas bangles",
  "बिंदी": "traditional auspicious red bindi on forehead",
  "मांग टीका": "ornate gold maang tikka forehead ornament",
  "मांगटीका": "ornate gold maang tikka forehead ornament",
  "नथ": "delicate traditional Indian bridal nose ring (nath)",
  "कमरबंद": "ornate gold waist belt (kamarbandh)",
  "पायल": "silver ankle bells (payal)",

  // English
  "traditional gold jewelry": "traditional Indian handcrafted 22k gold jewelry set",
  "kundan jewelry": "regal Kundan and polki heritage jewelry set",
  "jhumka earrings": "intricate traditional gold jhumka chandelier earrings",
  "jhumkas": "intricate gold jhumka chandelier earrings",
  "gold necklace": "regal layered gold necklace",
  "bangles": "traditional colorful glass and gold bangles",
  "bindi": "traditional auspicious bindi on forehead",
  "maang tikka": "ornate gold maang tikka forehead jewel",
  "nose ring": "delicate traditional Indian nose ring (nath)",
};

const HAIRSTYLE_MAP: Record<string, string> = {
  // Hindi
  "गजरा": "neatly styled hair adorned with fresh fragrant white jasmine flowers (gajra)",
  "जूड़ा": "elegant traditional hair bun adorned with jasmine garland",
  "चोटी": "long traditional neat Indian braid adorned with golden parandi",
  "खुले बाल": "cascading soft wavy loose dark hair",
  "लंबे बाल": "long lustrous dark Indian hair cascading over shoulders",
  "हेयरस्टाइल": "graceful traditional Indian coiffure",

  // English
  "jasmine flowers in hair": "hair adorned with fresh fragrant jasmine gajra garland",
  "gajra": "hair adorned with fresh fragrant white jasmine garland (gajra)",
  "hair bun": "elegant traditional hair bun adorned with flowers",
  "braided hair": "long traditional neat Indian braid",
  "loose hair": "cascading soft wavy dark hair falling naturally over shoulders",
  "long hair": "long lustrous dark hair with gentle natural waves",
};

const POSE_MAP: Record<string, string> = {
  // Hindi
  "नमस्ते": "folded hands in traditional Indian Namaste greeting gesture",
  "मुस्कुराती": "warm, graceful welcoming smile with expressive kind eyes",
  "मुस्कान": "serene dignified smile with gentle warmth",
  "खड़ी": "standing poised with dignified, regal posture",
  "बैठी": "seated comfortably and elegantly with refined grace",
  "दीये सजाती": "delicately lighting and arranging traditional clay oil lamps (diyas)",
  "दीया लिए हुए": "holding a glowing traditional clay diya lamp in hands",
  "दीया पकड़े": "delicately holding a warm glowing clay oil lamp",
  "रंगोली बनाती": "delicately crafting intricate vibrant rangoli patterns on floor",
  "आत्मविश्वास": "confident, empowered, poised posture radiating inner strength",
  "सौम्य": "graceful, calm, poised bearing",

  // English
  "namaste": "folded hands in traditional Indian Namaste greeting gesture",
  "smiling": "gentle welcoming smile with warm expressive eyes",
  "standing": "standing tall with regal, confident posture",
  "sitting": "seated gracefully in traditional dignified posture",
  "holding diya": "delicately holding a warm glowing clay diya oil lamp",
  "making rangoli": "artfully creating colorful rangoli patterns",
  "confident": "confident, empowered, professional poise radiating grace",
};

const BACKGROUND_MAP: Record<string, string> = {
  // Hindi
  "बगीचा": "lush blooming tropical garden with jasmine, hibiscus, and marigold flowers",
  "फूलों वाला बगीचा": "lush blooming floral garden with vibrant blossoms and greenery",
  "प्राकृतिक बगीचा": "serene natural lush garden with soft diffused green foliage",
  "महल": "opulent Rajasthani heritage palace courtyard with carved jharokha archways",
  "राजमहल": "regal Indian royal palace with ornate marble pillars and arches",
  "मंदिर": "ancient Indian temple architecture with intricately carved stone pillars",
  "कार्यालय": "modern professional office interior with warm contemporary lighting",
  "ऑफिस": "clean modern contemporary corporate office space",
  "गांव": "picturesque rural Indian village courtyard with clay pottery and rustic charm",
  "गाँव": "picturesque rural Indian village courtyard with clay pottery",
  "दीपावली": "festive Diwali celebration backdrop with glowing clay diyas and marigold garlands",
  "दिवाली": "festive Diwali setup adorned with illuminated oil lamps and colorful rangoli",
  "उत्सव": "festive celebration backdrop with cultural Indian decorations",
  "घर": "warm decorated Indian home interior with tasteful traditional decor",
  "हिमालय": "majestic snow-capped Himalayan mountain peaks in golden sunrise light",
  "गंगा घाट": "serene sacred Varanasi Ganga river ghat with temple reflections at dusk",

  // English
  "garden": "lush blooming tropical garden with fragrant marigolds and jasmine",
  "palace": "opulent Rajasthani royal palace courtyard with carved sandstone archways",
  "temple": "ancient Indian stone temple with intricately carved heritage pillars",
  "office": "modern clean executive office interior with tasteful ambient light",
  "village": "picturesque rural Indian village setting with warm rustic ambiance",
  "diwali": "festive Diwali celebration with glowing earthen diyas and marigold garlands",
  "festival": "vibrant traditional Indian festival backdrop with warm lighting",
  "home": "warm inviting Indian home with traditional brass lamps and rangoli",
};

const CAMERA_ANGLE_MAP: Record<string, string> = {
  // Hindi
  "क्लोज-अप": "intimate close-up portrait focusing on facial features and expressions",
  "क्लोज अप": "close-up portrait capturing expressive eyes and fine facial details",
  "हाफ-शॉट": "medium waist-up shot showing clothing, jewelry, and posture",
  "कमर तक": "medium waist-up portrait capturing posture and upper attire",
  "पूरा शरीर": "full-body environmental portrait showcasing the complete attire and drape",
  "फुल बॉडी": "full-length shot displaying full garment silhouette and posture",
  "सिनेमैटिक एंगल": "cinematic eye-level shot with shallow depth of field and soft background blur",

  // English
  "close-up": "intimate close-up portrait focusing on facial features and expressions",
  "portrait shot": "focused portrait framing with clean shallow depth of field",
  "medium shot": "medium waist-up shot displaying detailed attire, jewelry, and posture",
  "full-length": "full-body shot displaying full traditional drape and posture",
  "full body": "full-body shot capturing complete ensemble and environment",
};

const LIGHTING_MAP: Record<string, string> = {
  // Hindi
  "प्राकृतिक प्रकाश": "soft natural daylight with gentle ambient fill and soft shadows",
  "प्राकृतिक रोशनी": "soft diffused natural daylight, flattering ambient glow",
  "सिनेमैटिक प्रकाश": "cinematic dramatic lighting with subtle rim light and high dynamic range",
  "सुनहरी धूप": "golden hour late afternoon sunlight casting warm radiant sunbeams",
  "दीये की रोशनी": "warm flickering candlelight and golden oil lamp illumination",
  "दीपावली रोशनी": "warm festive illumination from glowing earthen diyas",
  "स्टुडियो लाइट": "professional studio portrait lighting with softbox diffusion",
  "सुबह का प्रकाश": "crisp morning golden sunrise light with gentle highlights",

  // English
  "natural light": "soft natural daylight with gentle ambient fill and soft shadows",
  "natural daylight": "soft diffused daylight with gentle natural highlights",
  "cinematic lighting": "cinematic dramatic lighting with rich contrast and warm rim light",
  "golden hour": "golden hour sunset glow casting warm radiant golden beams",
  "candlelight": "warm flickering candlelight and oil lamp illumination",
  "diya light": "warm intimate glow from flickering clay oil lamps",
  "studio lighting": "professional studio softbox lighting with balanced flattering exposure",
};

const SUBJECT_MAP: Record<string, { subject: string; gender: string }> = {
  // Hindi
  "उद्यमी महिला": { subject: "Indian woman entrepreneur", gender: "female" },
  "महिला उद्यमी": { subject: "Indian woman entrepreneur", gender: "female" },
  "उद्यमी": { subject: "Indian woman entrepreneur", gender: "female" },
  "दुल्हन": { subject: "radiant Indian bride", gender: "female" },
  "नववधू": { subject: "radiant Indian bride in bridal glory", gender: "female" },
  "लड़की": { subject: "young Indian woman", gender: "female" },
  "युवती": { subject: "graceful young Indian woman", gender: "female" },
  "माता": { subject: "dignified Indian mother", gender: "female" },
  "मां": { subject: "graceful Indian mother", gender: "female" },
  "दादी": { subject: "elderly Indian grandmother with serene wisdom", gender: "female" },
  "डॉक्टर": { subject: "Indian woman doctor", gender: "female" },
  "शिक्षिका": { subject: "Indian woman teacher", gender: "female" },
  "किसान महिला": { subject: "resilient Indian woman farmer", gender: "female" },
  "कलाकार": { subject: "creative Indian woman artist", gender: "female" },
  "महारानी": { subject: "regal Indian queen in royal grandeur", gender: "female" },
  "रानी": { subject: "regal Indian royal woman", gender: "female" },
  "महिला": { subject: "graceful Indian woman", gender: "female" },
  "नारी": { subject: "empowered Indian woman", gender: "female" },
  "स्त्री": { subject: "graceful Indian woman", gender: "female" },

  // English
  "woman entrepreneur": { subject: "Indian woman entrepreneur", gender: "female" },
  "female entrepreneur": { subject: "Indian woman entrepreneur", gender: "female" },
  "bride": { subject: "radiant Indian bride", gender: "female" },
  "young woman": { subject: "graceful young Indian woman", gender: "female" },
  "girl": { subject: "young Indian woman", gender: "female" },
  "mother": { subject: "graceful Indian mother", gender: "female" },
  "doctor": { subject: "Indian woman doctor", gender: "female" },
  "teacher": { subject: "Indian woman teacher", gender: "female" },
  "farmer": { subject: "resilient Indian woman farmer", gender: "female" },
  "artist": { subject: "creative Indian woman artist", gender: "female" },
  "queen": { subject: "regal Indian queen", gender: "female" },
  "woman": { subject: "graceful Indian woman", gender: "female" },
  "lady": { subject: "graceful Indian woman", gender: "female" },
};

export class PromptEngineer {
  /**
   * Parse user instructions into a detailed, structured visual prompt representation.
   * Accurately extracts and preserves:
   * - subject & gender
   * - clothing & saree colour & blouse colour
   * - jewellery & accessories
   * - hairstyle & hair adornments
   * - pose & body proportions
   * - facial features when reference image is supplied
   * - background & environment
   * - camera angle & composition
   * - lighting & atmosphere
   * - image style & aspect ratio
   */
  static parsePrompt(
    rawPrompt: string,
    style: ImageStyle = "realistic",
    mode: ImageCreationMode = "text-to-image",
    aspectRatio: AspectRatio = "1:1",
    hasReferenceImage: boolean = false
  ): StructuredVisualPrompt {
    const text = (rawPrompt || "").trim();
    const lower = text.toLowerCase();

    // 1. Detect if this is an image-to-image / image-edit instruction
    const isEditKeywords =
      lower.includes("रखो") ||
      lower.includes("रखें") ||
      lower.includes("बदलकर") ||
      lower.includes("बदलो") ||
      lower.includes("बदलें") ||
      lower.includes("बदल दो") ||
      lower.includes("बदल दीजिये") ||
      lower.includes("यही फोटो") ||
      lower.includes("वही फोटो") ||
      lower.includes("चेहरा और पहचान") ||
      lower.includes("जैसी है वैसी") ||
      lower.includes("जैसा है वैसा") ||
      lower.includes("uploaded") ||
      lower.includes("reference") ||
      lower.includes("keep same") ||
      lower.includes("preserve") ||
      lower.includes("change only") ||
      lower.includes("modify") ||
      lower.includes("replace") ||
      lower.includes("recolor") ||
      lower.includes("edit");

    const isImageEdit =
      mode === "image-to-image" || (hasReferenceImage && isEditKeywords);

    // 2. Extract colors accurately with substring prevention (e.g. गहरा vs हरा)
    const colorMatch = findLongestMatch(text, COLOR_MAP, isSubstringOfGahara);
    let matchedColor = colorMatch ? colorMatch.englishValue : "";

    // 3. Extract blouse color specifically if user mentioned blouse color
    let matchedBlouseColor = "";
    const blouseMentions = [
      "ब्लाउज का रंग",
      "ब्लाउज़ का रंग",
      "ब्लाउज",
      "blouse color",
      "blouse colour",
      "blouse",
    ];
    for (const bTerm of blouseMentions) {
      const bIdx = lower.indexOf(bTerm);
      if (bIdx !== -1) {
        // Look in window around blouse mention for color
        const windowText = text.slice(Math.max(0, bIdx - 20), Math.min(text.length, bIdx + 30));
        const bColor = findLongestMatch(windowText, COLOR_MAP, isSubstringOfGahara);
        if (bColor) {
          matchedBlouseColor = bColor.englishValue;
          break;
        }
      }
    }

    // 4. Extract clothing
    const clothingMatch = findLongestMatch(text, CLOTHING_MAP);
    let matchedClothing = clothingMatch ? clothingMatch.englishValue : "";
    if (!matchedClothing) {
      if (lower.includes("saree") || text.includes("साड़ी") || text.includes("साड़ी")) {
        matchedClothing = "traditional Indian saree";
      } else if (lower.includes("lehenga") || text.includes("लहंगा")) {
        matchedClothing = "embroidered festive lehenga choli";
      } else if (lower.includes("kurti") || text.includes("कुर्ती")) {
        matchedClothing = "graceful Indian ethnic kurti";
      } else if (lower.includes("salwar") || text.includes("सलवार")) {
        matchedClothing = "traditional elegant salwar kameez";
      } else {
        matchedClothing = "traditional Indian ethnic attire";
      }
    }

    // 5. Extract jewelry
    const jewelryMatch = findLongestMatch(text, JEWELRY_MAP);
    let matchedJewelry = jewelryMatch ? jewelryMatch.englishValue : "";

    // 6. Extract hairstyle
    const hairMatch = findLongestMatch(text, HAIRSTYLE_MAP);
    let matchedHairstyle = hairMatch ? hairMatch.englishValue : "";

    // 7. Extract pose
    const poseMatch = findLongestMatch(text, POSE_MAP);
    let matchedPose = poseMatch ? poseMatch.englishValue : "";

    // 8. Extract lighting
    const lightingMatch = findLongestMatch(text, LIGHTING_MAP);
    let matchedLighting = lightingMatch ? lightingMatch.englishValue : "";

    // 9. Extract background
    const bgMatch = findLongestMatch(text, BACKGROUND_MAP);
    let matchedBackground = bgMatch ? bgMatch.englishValue : "";

    // 10. Extract camera angle
    const cameraMatch = findLongestMatch(text, CAMERA_ANGLE_MAP);
    let matchedCameraAngle = cameraMatch ? cameraMatch.englishValue : "";

    // 11. Determine subject & gender
    const subjectMatch = findLongestMatch(text, SUBJECT_MAP as unknown as Record<string, string>);
    let subject = "graceful Indian woman";
    let gender = "female";
    if (subjectMatch) {
      const found = SUBJECT_MAP[subjectMatch.matchedKey];
      if (found) {
        subject = found.subject;
        gender = found.gender;
      }
    }

    // 12. Body proportions & facial features
    let bodyProportions = "natural authentic body proportions, graceful poise";
    let facialFeatures: string | undefined = undefined;

    if (
      text.includes("चेहरा") ||
      text.includes("पहचान") ||
      lower.includes("face") ||
      lower.includes("identity") ||
      lower.includes("features") ||
      isImageEdit
    ) {
      facialFeatures =
        "preserve exact facial features, facial contours, eyes, expression, and distinct likeness from uploaded reference photo";
    }

    // 13. Composition
    let requestedComposition: string | undefined = undefined;
    if (text.includes("कंपोजिशन") || lower.includes("composition") || lower.includes("framing")) {
      requestedComposition = "balanced aesthetic composition with clean visual depth";
    }

    // 14. Handle Edit elements (Preservation vs Modification Contract)
    const preservedElements: string[] = [];
    const requestedModifications: string[] = [];

    if (isImageEdit) {
      // Elements to strictly preserve
      if (
        text.includes("चेहरा") ||
        text.includes("पहचान") ||
        text.includes("जैसी है वैसी") ||
        text.includes("जैसा है वैसा") ||
        lower.includes("face") ||
        lower.includes("identity") ||
        lower.includes("likeness")
      ) {
        preservedElements.push(
          "exact facial likeness, identity, facial structure, eyes, and expression from reference"
        );
      } else {
        preservedElements.push("subject facial identity and likeness from reference photo");
      }

      if (
        text.includes("यही फोटो रखो") ||
        text.includes("वही फोटो") ||
        lower.includes("same photo") ||
        lower.includes("keep pose") ||
        lower.includes("same pose")
      ) {
        preservedElements.push("camera angle, pose, body posture, and scene framing");
      } else {
        preservedElements.push("body pose and camera framing unless modified");
      }

      // Modifications requested
      if (
        text.includes("साड़ी का रंग") ||
        text.includes("साड़ी का रंग") ||
        lower.includes("saree color") ||
        lower.includes("saree colour")
      ) {
        const colorName = matchedColor || "new requested color";
        requestedModifications.push(
          `recolor the saree to rich ${colorName} while preserving fabric texture, folds, and zari details`
        );
      } else if (matchedColor && (text.includes("रंग") || lower.includes("color"))) {
        requestedModifications.push(`recolor attire to ${matchedColor}`);
      }

      if (matchedBlouseColor) {
        requestedModifications.push(
          `change blouse color to ${matchedBlouseColor}`
        );
      }

      if (
        matchedBackground &&
        (text.includes("पृष्ठभूमि") ||
          text.includes("बैकग्राउंड") ||
          lower.includes("background"))
      ) {
        requestedModifications.push(
          `change background environment to ${matchedBackground}`
        );
      }

      if (matchedJewelry && (text.includes("आभूषण") || text.includes("गहने") || lower.includes("jewelry"))) {
        requestedModifications.push(`adorn with ${matchedJewelry}`);
      }

      if (matchedHairstyle && (text.includes("बाल") || text.includes("जूड़ा") || lower.includes("hair"))) {
        requestedModifications.push(`style hair with ${matchedHairstyle}`);
      }
    }

    // 15. Assemble comprehensive final diffusion prompt
    const finalDiffusionPrompt = this.buildDiffusionPrompt({
      rawText: text,
      isImageEdit,
      subject,
      gender,
      clothing: matchedClothing,
      sareeColor: matchedColor,
      blouseColor: matchedBlouseColor,
      jewelry: matchedJewelry,
      hairstyle: matchedHairstyle,
      lighting: matchedLighting,
      background: matchedBackground,
      pose: matchedPose,
      cameraAngle: matchedCameraAngle,
      bodyProportions,
      facialFeatures,
      style,
      aspectRatio,
      preservedElements,
      requestedModifications,
    });

    return {
      subject,
      gender,
      clothing: matchedClothing,
      sareeColor: matchedColor || undefined,
      blouseColor: matchedBlouseColor || undefined,
      jewelry: matchedJewelry || undefined,
      hairstyle: matchedHairstyle || undefined,
      pose: matchedPose || undefined,
      bodyProportions,
      facialFeatures,
      background: matchedBackground || undefined,
      cameraAngle: matchedCameraAngle || undefined,
      lighting: matchedLighting || undefined,
      environment: matchedBackground || undefined,
      imageStyle: style,
      aspectRatio,
      requestedComposition,
      isImageEdit,
      preservedElements: preservedElements.length > 0 ? preservedElements : undefined,
      requestedModifications:
        requestedModifications.length > 0 ? requestedModifications : undefined,
      finalDiffusionPrompt,
    };
  }

  private static buildDiffusionPrompt(params: {
    rawText: string;
    isImageEdit: boolean;
    subject: string;
    gender: string;
    clothing: string;
    sareeColor: string;
    blouseColor: string;
    jewelry: string;
    hairstyle: string;
    lighting: string;
    background: string;
    pose: string;
    cameraAngle: string;
    bodyProportions: string;
    facialFeatures?: string;
    style: ImageStyle;
    aspectRatio: AspectRatio;
    preservedElements: string[];
    requestedModifications: string[];
  }): string {
    const parts: string[] = [];

    if (params.isImageEdit) {
      // Structured instruction-following image edit prompt
      parts.push("image-to-image precise visual edit");

      if (params.preservedElements.length > 0) {
        parts.push(`strictly preserving: ${params.preservedElements.join("; ")}`);
      } else {
        parts.push("strictly preserving reference subject face, identity, and pose");
      }

      if (params.requestedModifications.length > 0) {
        parts.push(`applied modifications: ${params.requestedModifications.join("; ")}`);
      } else if (params.sareeColor) {
        parts.push(`change saree color to ${params.sareeColor}`);
      }

      if (params.clothing) {
        const fullClothing = [
          params.sareeColor,
          params.clothing,
          params.blouseColor ? `with ${params.blouseColor} blouse` : "",
        ]
          .filter(Boolean)
          .join(" ");
        parts.push(`attire details: ${fullClothing}`);
      }

      if (params.cameraAngle) {
        parts.push(params.cameraAngle);
      }
    } else {
      // Text to Image high-fidelity structured visual prompt
      const fullSubject = [
        params.subject,
        params.pose,
        params.bodyProportions,
      ]
        .filter(Boolean)
        .join(", ");
      parts.push(fullSubject);

      // Clothing, Saree color & Blouse color
      const clothingParts = [
        params.sareeColor ? `wearing a stunning ${params.sareeColor}` : "wearing an elegant",
        params.clothing,
        params.blouseColor ? `with a complementary ${params.blouseColor} tailored blouse` : "",
      ]
        .filter(Boolean)
        .join(" ");
      parts.push(clothingParts);

      // Hairstyle & hair accessories
      if (params.hairstyle) {
        parts.push(params.hairstyle);
      }

      // Jewelry & ornaments
      if (params.jewelry) {
        parts.push(`adorned with ${params.jewelry}`);
      }

      // Camera angle & framing
      if (params.cameraAngle) {
        parts.push(params.cameraAngle);
      }

      // Lighting & atmosphere
      if (params.lighting) {
        parts.push(params.lighting);
      } else {
        parts.push("soft natural ambient daylight with gentle golden highlights");
      }

      // Background & environment
      if (params.background) {
        parts.push(`set against ${params.background}`);
      }
    }

    // Add style-specific aesthetics
    switch (params.style) {
      case "cinematic":
        parts.push(
          "cinematic 35mm film photograph, anamorphic bokeh, rich color grading, shallow depth of field, 8k"
        );
        break;
      case "portrait":
        parts.push(
          "master studio portrait photography, sharp focus on expressive eyes, soft flattering skin illumination, clean depth"
        );
        break;
      case "fantasy":
        parts.push(
          "enchanting fantasy digital art, ethereal atmospheric lighting, magical luminous particles, intricate detailing"
        );
        break;
      case "illustration":
        parts.push(
          "modern editorial digital art illustration, clean precise linework, vibrant harmonious color palette"
        );
        break;
      case "painting":
        parts.push(
          "fine art oil on canvas masterpiece, rich impasto brushwork, warm chiaroscuro classical aesthetic"
        );
        break;
      case "cartoon":
        parts.push(
          "clean 2D animated character illustration, expressive facial design, crisp colorful outlines"
        );
        break;
      case "poster":
        parts.push(
          "bold graphic art poster, high visual contrast, striking dynamic composition, minimalist typography aesthetic"
        );
        break;
      case "realistic":
      default:
        parts.push(
          "photorealistic, natural authentic skin texture, sharp focus, 8k resolution, true-to-life colors"
        );
        break;
    }

    return parts.join(", ");
  }
}
