import { ChatMessage, ChatThread, ResponseStyle } from "../types/chat";

export const STORAGE_THREADS_KEY = "vesper_chat_threads_v2";
export const STORAGE_ACTIVE_THREAD_KEY = "vesper_active_thread_id_v2";
export const STORAGE_STYLE_KEY = "vesper_response_style_v2";
export const STORAGE_THEME_KEY = "vesper_theme_dark_v2";

// Legacy keys for seamless migration
const LEGACY_SESSION_THREADS = "vesper_private_session_threads_v1";
const LEGACY_SESSION_STYLE = "vesper_response_style_v1";
const LEGACY_SESSION_THEME = "vesper_theme_dark_v1";

const IDB_NAME = "vesper_chat_db_v2";
const IDB_STORE = "chat_data";
const IDB_VERSION = 1;

/**
 * Open IndexedDB database safely
 */
function openIDB(): Promise<IDBDatabase | null> {
  if (typeof window === "undefined" || !("indexedDB" in window)) {
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    try {
      const request = indexedDB.open(IDB_NAME, IDB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) {
          db.createObjectStore(IDB_STORE);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => {
        console.warn("IndexedDB open error:", request.error);
        resolve(null);
      };
    } catch (err) {
      console.warn("IndexedDB open exception:", err);
      resolve(null);
    }
  });
}

/**
 * Set a key-value pair in IndexedDB
 */
export async function idbSet<T>(key: string, value: T): Promise<void> {
  try {
    const db = await openIDB();
    if (!db) return;
    await new Promise<void>((resolve, reject) => {
      try {
        const tx = db.transaction(IDB_STORE, "readwrite");
        const store = tx.objectStore(IDB_STORE);
        store.put(value, key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      } catch (e) {
        reject(e);
      }
    });
  } catch (err) {
    console.warn("IndexedDB put error:", err);
  }
}

/**
 * Get a key-value pair from IndexedDB
 */
export async function idbGet<T>(key: string): Promise<T | null> {
  try {
    const db = await openIDB();
    if (!db) return null;
    return await new Promise<T | null>((resolve) => {
      try {
        const tx = db.transaction(IDB_STORE, "readonly");
        const store = tx.objectStore(IDB_STORE);
        const req = store.get(key);
        req.onsuccess = () => resolve(req.result ?? null);
        req.onerror = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
  } catch {
    return null;
  }
}

/**
 * Delete a key or clear IndexedDB
 */
export async function idbClear(): Promise<void> {
  try {
    const db = await openIDB();
    if (!db) return;
    await new Promise<void>((resolve) => {
      try {
        const tx = db.transaction(IDB_STORE, "readwrite");
        const store = tx.objectStore(IDB_STORE);
        store.clear();
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch {
        resolve();
      }
    });
  } catch {
    // ignore
  }
}

/**
 * Create a fresh initial thread
 */
export function createInitialThread(): ChatThread {
  const now = Date.now();
  return {
    id: `thread-${now}-${Math.random().toString(36).slice(2, 7)}`,
    title: "New Private Conversation",
    createdAt: now,
    updatedAt: now,
    messages: [],
  };
}

/**
 * Derive clean title from the first message
 */
export function deriveThreadTitle(firstUserText: string): string {
  const cleaned = firstUserText.replace(/\s+/g, " ").trim();
  if (!cleaned) return "New Private Conversation";
  return cleaned.length > 42 ? `${cleaned.slice(0, 42)}…` : cleaned;
}

/**
 * Sanitize and clean restored threads
 */
export function sanitizeThreads(rawThreads: unknown): ChatThread[] | null {
  if (!Array.isArray(rawThreads) || rawThreads.length === 0) {
    return null;
  }

  const validThreads: ChatThread[] = [];

  for (const item of rawThreads) {
    if (!item || typeof item !== "object") continue;
    const t = item as Partial<ChatThread>;
    if (!t.id || typeof t.id !== "string") continue;

    const messages: ChatMessage[] = [];
    if (Array.isArray(t.messages)) {
      for (const m of t.messages) {
        if (!m || typeof m !== "object") continue;
        const msg = m as Partial<ChatMessage>;
        if (!msg.id || typeof msg.id !== "string") continue;
        if (msg.role !== "user" && msg.role !== "model") continue;
        messages.push({
          id: msg.id,
          role: msg.role,
          text: typeof msg.text === "string" ? msg.text : "",
          timestamp: typeof msg.timestamp === "number" ? msg.timestamp : Date.now(),
          pinned: Boolean(msg.pinned),
          responseStyle: msg.responseStyle,
          isError: Boolean(msg.isError),
          // Any interrupted streaming message should no longer show as streaming on refresh
          isStreaming: false,
        });
      }
    }

    validThreads.push({
      id: t.id,
      title: typeof t.title === "string" && t.title.trim() ? t.title : "Conversation",
      createdAt: typeof t.createdAt === "number" ? t.createdAt : Date.now(),
      updatedAt: typeof t.updatedAt === "number" ? t.updatedAt : Date.now(),
      messages,
    });
  }

  return validThreads.length > 0 ? validThreads : null;
}

/**
 * Synchronous initial load of threads from persistent storage
 */
export function loadInitialThreads(): ChatThread[] {
  if (typeof window === "undefined") {
    return [createInitialThread()];
  }

  // 1. Try primary persistent localStorage
  try {
    const raw = localStorage.getItem(STORAGE_THREADS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const sanitized = sanitizeThreads(parsed);
      if (sanitized && sanitized.length > 0) {
        return sanitized;
      }
    }
  } catch (err) {
    console.warn("Failed reading threads from localStorage:", err);
  }

  // 2. Try legacy migration from sessionStorage if user had an active session
  try {
    const legacyRaw = sessionStorage.getItem(LEGACY_SESSION_THREADS);
    if (legacyRaw) {
      const parsed = JSON.parse(legacyRaw);
      const sanitized = sanitizeThreads(parsed);
      if (sanitized && sanitized.length > 0) {
        // Immediately persist to localStorage for future survival
        persistThreadsSync(sanitized);
        return sanitized;
      }
    }
  } catch {
    // ignore
  }

  // 3. Fallback: fresh conversation thread
  const initial = [createInitialThread()];
  persistThreadsSync(initial);
  return initial;
}

/**
 * Synchronous initial load of active thread ID
 */
export function loadInitialActiveThreadId(threads: ChatThread[]): string {
  if (typeof window === "undefined" || threads.length === 0) {
    return "";
  }

  try {
    const savedActiveId = localStorage.getItem(STORAGE_ACTIVE_THREAD_KEY);
    if (savedActiveId && threads.some((t) => t.id === savedActiveId)) {
      return savedActiveId;
    }
  } catch {
    // ignore
  }

  return threads[0]?.id || "";
}

/**
 * Synchronous initial load of response style
 */
export function loadInitialResponseStyle(): ResponseStyle {
  if (typeof window === "undefined") return "detailed";

  try {
    const saved = (localStorage.getItem(STORAGE_STYLE_KEY) ||
      sessionStorage.getItem(LEGACY_SESSION_STYLE)) as ResponseStyle | null;
    if (
      saved === "detailed" ||
      saved === "concise" ||
      saved === "step-by-step" ||
      saved === "creative"
    ) {
      return saved;
    }
  } catch {
    // ignore
  }
  return "detailed";
}

/**
 * Synchronous initial load of theme
 */
export function loadInitialTheme(): boolean {
  if (typeof window === "undefined") return false;

  try {
    const saved =
      localStorage.getItem(STORAGE_THEME_KEY) ||
      sessionStorage.getItem(LEGACY_SESSION_THEME);
    if (saved !== null) {
      return saved === "true";
    }
    // Also check system preference
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      return true;
    }
  } catch {
    // ignore
  }
  return false;
}

/**
 * Synchronous and persistent save of threads (localStorage + async IndexedDB)
 */
export function persistThreadsSync(threads: ChatThread[]): void {
  if (typeof window === "undefined") return;

  try {
    localStorage.setItem(STORAGE_THREADS_KEY, JSON.stringify(threads));
  } catch (err) {
    console.warn("Failed saving threads to localStorage (quota exceeded?):", err);
  }

  // Backup to IndexedDB asynchronously
  idbSet(STORAGE_THREADS_KEY, threads).catch(() => {});
}

/**
 * Persist active thread ID
 */
export function persistActiveThreadIdSync(threadId: string): void {
  if (typeof window === "undefined") return;

  try {
    localStorage.setItem(STORAGE_ACTIVE_THREAD_KEY, threadId);
  } catch {
    // ignore
  }

  idbSet(STORAGE_ACTIVE_THREAD_KEY, threadId).catch(() => {});
}

/**
 * Persist response style
 */
export function persistResponseStyleSync(style: ResponseStyle): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_STYLE_KEY, style);
  } catch {
    // ignore
  }
  idbSet(STORAGE_STYLE_KEY, style).catch(() => {});
}

/**
 * Persist theme
 */
export function persistThemeSync(darkMode: boolean): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_THEME_KEY, String(darkMode));
  } catch {
    // ignore
  }
  idbSet(STORAGE_THEME_KEY, darkMode).catch(() => {});
}

/**
 * Check IndexedDB on startup in case it contains more data/threads than localStorage
 */
export async function syncFromIndexedDB(): Promise<{
  threads: ChatThread[] | null;
  activeThreadId: string | null;
}> {
  try {
    const [threads, activeThreadId] = await Promise.all([
      idbGet<ChatThread[]>(STORAGE_THREADS_KEY),
      idbGet<string>(STORAGE_ACTIVE_THREAD_KEY),
    ]);

    const sanitized = sanitizeThreads(threads);
    return {
      threads: sanitized,
      activeThreadId: activeThreadId || null,
    };
  } catch {
    return { threads: null, activeThreadId: null };
  }
}

/**
 * Clear all persistent storage (only when user explicitly wipes history)
 */
export async function clearAllPersistentHistory(): Promise<void> {
  if (typeof window === "undefined") return;

  try {
    localStorage.removeItem(STORAGE_THREADS_KEY);
    localStorage.removeItem(STORAGE_ACTIVE_THREAD_KEY);
    sessionStorage.removeItem(LEGACY_SESSION_THREADS);
  } catch {
    // ignore
  }

  await idbClear();
}
