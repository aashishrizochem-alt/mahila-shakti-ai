import { GeneratedImageItem } from "../types/imageCreator";
import { idbGet, idbSet } from "./chatStorage";

const STORAGE_IMAGES_KEY = "vesper_generated_images_v1";
const IDB_IMAGES_KEY = "images_history";
const MAX_LOCAL_STORAGE_ITEMS = 20;

export function loadStoredImages(): GeneratedImageItem[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = localStorage.getItem(STORAGE_IMAGES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn("Failed to load images from localStorage:", err);
  }
  return [];
}

export function saveStoredImages(images: GeneratedImageItem[]): void {
  if (typeof window === "undefined") return;

  try {
    // Keep most recent items in localStorage to stay safely within quotas
    const trimmed = images.slice(0, MAX_LOCAL_STORAGE_ITEMS);
    localStorage.setItem(STORAGE_IMAGES_KEY, JSON.stringify(trimmed));
  } catch (err) {
    console.warn("localStorage quota exceeded for images, relying on IndexedDB:", err);
  }

  // Save all items to IndexedDB
  idbSet(IDB_IMAGES_KEY, images).catch(() => {});
}

export function addStoredImage(item: GeneratedImageItem): GeneratedImageItem[] {
  const current = loadStoredImages();
  const updated = [item, ...current.filter((x) => x.id !== item.id)];
  saveStoredImages(updated);
  return updated;
}

export function deleteStoredImage(id: string): GeneratedImageItem[] {
  const current = loadStoredImages();
  const updated = current.filter((x) => x.id !== id);
  saveStoredImages(updated);
  return updated;
}

export async function syncImagesFromIndexedDB(): Promise<GeneratedImageItem[] | null> {
  try {
    const stored = await idbGet<GeneratedImageItem[]>(IDB_IMAGES_KEY);
    if (Array.isArray(stored) && stored.length > 0) {
      return stored;
    }
  } catch {
    // ignore
  }
  return null;
}
