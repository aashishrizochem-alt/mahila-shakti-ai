import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register PWA service worker with automatic background cache update
registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log('Mahila Shakti AI: New version available, reloading in background');
  },
  onOfflineReady() {
    console.log('Mahila Shakti AI: PWA is cached and ready for offline use');
  },
});

createRoot(document.getElementById('root')!).render(<App />);
