export type ResponseStyle = "detailed" | "concise" | "step-by-step" | "creative";

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: number;
  isStreaming?: boolean;
  isError?: boolean;
  pinned?: boolean;
  responseStyle?: ResponseStyle;
}

export interface ChatThread {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
}

export interface StarterPrompt {
  id: string;
  category: string;
  title: string;
  prompt: string;
}

export const RESPONSE_STYLES: {
  id: ResponseStyle;
  label: string;
  description: string;
}[] = [
  {
    id: "detailed",
    label: "Detailed",
    description: "Comprehensive, nuanced explanations with context",
  },
  {
    id: "concise",
    label: "Concise",
    description: "Direct, focused answers for quick reading on mobile",
  },
  {
    id: "step-by-step",
    label: "Step-by-Step",
    description: "Structured numbered breakdowns and actionable guides",
  },
  {
    id: "creative",
    label: "Creative",
    description: "Expressive brainstorming, writing, and fresh perspectives",
  },
];

export const STARTER_PROMPTS: StarterPrompt[] = [
  {
    id: "explain-concept",
    category: "Deep Dive",
    title: "Explain how noise-canceling headphones work",
    prompt:
      "Explain how active noise-canceling headphones work in clear, everyday language, including why they handle low-frequency hums better than sudden sharp sounds.",
  },
  {
    id: "travel-itinerary",
    category: "Planning",
    title: "Plan a 4-day walkable itinerary in Kyoto",
    prompt:
      "Create a relaxed, walkable 4-day itinerary for Kyoto focused on quiet morning neighborhoods, local food markets, and practical transit tips.",
  },
  {
    id: "career-writing",
    category: "Writing",
    title: "Draft a polite message declining a meeting",
    prompt:
      "Write a warm, professional message declining a recurring status meeting while offering an asynchronous written update instead.",
  },
  {
    id: "health-routine",
    category: "Wellness",
    title: "Design a 15-minute morning mobility routine",
    prompt:
      "Give me a simple 15-minute morning mobility routine I can do in a small bedroom with zero equipment to relieve stiff shoulders and lower back tension.",
  },
];
