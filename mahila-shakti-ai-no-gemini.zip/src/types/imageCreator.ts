export type ImageStyle =
  | "realistic"
  | "cinematic"
  | "portrait"
  | "fantasy"
  | "illustration"
  | "painting"
  | "cartoon"
  | "poster";

export type AspectRatio = "1:1" | "4:5" | "16:9" | "9:16";

export type ImageCreationMode = "text-to-image" | "image-to-image";

export interface GeneratedImageItem {
  id: string;
  imageUrl: string; // base64 data URL
  prompt: string;
  mode?: ImageCreationMode;
  style: ImageStyle;
  aspectRatio: AspectRatio;
  seed: number;
  createdAt: number;
  width?: number;
  height?: number;
  referenceImageName?: string;
}

export interface StyleOption {
  id: ImageStyle;
  label: string;
  labelHi: string;
  description: string;
  badge: string;
}

export const IMAGE_STYLES: StyleOption[] = [
  {
    id: "realistic",
    label: "Realistic",
    labelHi: "रियलिस्टिक",
    description: "Authentic photography with natural skin texture and lighting",
    badge: "📸",
  },
  {
    id: "cinematic",
    label: "Cinematic",
    labelHi: "सिनेमैटिक",
    description: "Dramatic movie still with depth of field and color grading",
    badge: "🎬",
  },
  {
    id: "portrait",
    label: "Portrait",
    labelHi: "पोर्ट्रेट",
    description: "Focused expressive studio lighting with soft bokeh",
    badge: "👤",
  },
  {
    id: "fantasy",
    label: "Fantasy",
    labelHi: "फैंटेसी",
    description: "Magical atmosphere, ethereal glow and mythical details",
    badge: "✨",
  },
  {
    id: "illustration",
    label: "Illustration",
    labelHi: "इलस्ट्रेशन",
    description: "Clean modern digital art with harmonious palette",
    badge: "🎨",
  },
  {
    id: "painting",
    label: "Painting",
    labelHi: "पेंटिंग",
    description: "Rich oil canvas texture and artistic expressive strokes",
    badge: "🖌️",
  },
  {
    id: "cartoon",
    label: "Cartoon",
    labelHi: "कार्टून",
    description: "Stylized 2D animated character art with crisp outlines",
    badge: "🧸",
  },
  {
    id: "poster",
    label: "Poster",
    labelHi: "पोस्टर",
    description: "Bold graphic composition with striking artistic contrast",
    badge: "📰",
  },
];

export interface AspectRatioOption {
  id: AspectRatio;
  label: string;
  sublabel: string;
  aspectClass: string;
  widthRatio: number;
  heightRatio: number;
}

export const ASPECT_RATIOS: AspectRatioOption[] = [
  {
    id: "1:1",
    label: "1:1",
    sublabel: "Square",
    aspectClass: "aspect-square",
    widthRatio: 1,
    heightRatio: 1,
  },
  {
    id: "4:5",
    label: "4:5",
    sublabel: "Portrait",
    aspectClass: "aspect-[4/5]",
    widthRatio: 4,
    heightRatio: 5,
  },
  {
    id: "16:9",
    label: "16:9",
    sublabel: "Landscape",
    aspectClass: "aspect-[16/9]",
    widthRatio: 16,
    heightRatio: 9,
  },
  {
    id: "9:16",
    label: "9:16",
    sublabel: "Story",
    aspectClass: "aspect-[9/16]",
    widthRatio: 9,
    heightRatio: 16,
  },
];

export interface PromptExample {
  title: string;
  prompt: string;
  style: ImageStyle;
  aspectRatio: AspectRatio;
  language: "hi" | "en";
}

export const PROMPT_EXAMPLES: PromptExample[] = [
  {
    title: "कढ़ाईदार साड़ी में भारतीय महिला",
    prompt:
      "एक भारतीय महिला हरे और गुलाबी रंग की सुंदर कढ़ाईदार साड़ी पहने हुए, सिनेमैटिक फोटो, प्राकृतिक प्रकाश",
    style: "cinematic",
    aspectRatio: "1:1",
    language: "hi",
  },
  {
    title: "सशक्त महिला उद्यमी",
    prompt:
      "पारंपरिक भारतीय परिधान में आत्मविश्वास से भरी महिला उद्यमी, आधुनिक कार्यालय पृष्ठभूमि, प्राकृतिक मुस्कान, उच्च विवरण",
    style: "realistic",
    aspectRatio: "4:5",
    language: "hi",
  },
  {
    title: "दीपावली रोशनी में पारंपरिक परिधान",
    prompt:
      "सुंदर रेशमी पोशाक में दीये सजाती भारतीय महिला, सुनहरी दीप ज्योति, उत्सव का मनमोहक वातावरण",
    style: "portrait",
    aspectRatio: "1:1",
    language: "hi",
  },
  {
    title: "Indian Leader Portrait",
    prompt:
      "An inspiring Indian woman in an elegant handcrafted handloom saree, soft studio lighting, dignified expressive portrait",
    style: "portrait",
    aspectRatio: "4:5",
    language: "en",
  },
  {
    title: "Himalayan Sunrise Painting",
    prompt:
      "Traditional Indian mountain woman surrounded by blooming rhododendrons with snow-capped Himalayan peaks at sunrise, oil painting",
    style: "painting",
    aspectRatio: "16:9",
    language: "en",
  },
];
