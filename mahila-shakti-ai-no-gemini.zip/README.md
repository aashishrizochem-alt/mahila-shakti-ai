<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/97caadad-2ee8-45eb-8e28-f598f3662406

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `AI_BASE_URL / AI_API_KEY / AI_MODEL` in [.env.local](.env.local) to your OpenAI-compatible local AI server API key
3. Run the app:
   `npm run dev`
