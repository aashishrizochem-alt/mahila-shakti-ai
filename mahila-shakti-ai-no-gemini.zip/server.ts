import dotenv from "dotenv";
import express from "express";
import type { Request, Response } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { registerImageRoutes } from "./src/server/image/imageService.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: "10mb" }));
registerImageRoutes(app);

app.get("/health", (_req: Request, res: Response) => res.status(200).send("OK"));
app.get("/api/health", (_req: Request, res: Response) =>
  res.status(200).json({ status: "ok", ai: "openai-compatible" })
);

interface ChatTurnInput {
  role: "user" | "model";
  text: string;
}
interface ChatRequestBody {
  messages: ChatTurnInput[];
  responseStyle?: "detailed" | "concise" | "step-by-step" | "creative";
}

/**
 * Mahila Shakti AI now uses an OpenAI-compatible local AI endpoint instead of
 * Google Gemini. This works with Ollama, LM Studio, llama.cpp and other
 * OpenAI-compatible servers. No Gemini key is required.
 */
function getAIConfig() {
  const baseUrl = (process.env.AI_BASE_URL || "http://127.0.0.1:11434/v1").replace(/\/$/, "");
  const model = process.env.AI_MODEL || "llama3.2:3b";
  const apiKey = process.env.AI_API_KEY || "ollama";
  return { baseUrl, model, apiKey };
}

function sanitizeChatOutput(text: string): string {
  if (!text) return "";
  const lower = text.toLowerCase();
  if (
    lower.includes("dalle.text2im") ||
    lower.includes('"action": "dalle') ||
    lower.includes('"action":"dalle') ||
    lower.includes("action_input") ||
    (lower.trim().startsWith("{") && lower.includes('"action"'))
  ) {
    return "नमस्ते! वास्तविक तस्वीर तैयार करने के लिए, कृपया ऐप के सबसे ऊपर दिए गए **'🖼️ Image Creator'** विकल्प पर टैप करें।";
  }
  return text;
}

function buildSystemInstruction(style: string = "detailed"): string {
  const base =
    "You are Mahila Shakti AI, an intelligent, private, thoughtful, and articulate AI assistant designed to empower women with knowledge, advice, and confidential conversational support. " +
    "Provide clear, natural-language responses that are easy to read on a phone screen. " +
    "Use well-structured paragraphs, bullet points where helpful, and clear headings or code blocks when relevant. " +
    "Never state or imply any underlying model name, version, family, or provider. If asked who you are, simply state that you are Mahila Shakti AI, a private AI chat assistant. " +
    "You are a text chat assistant and do not generate images inside this text stream. Never output JSON tool calls, functions, or DALL-E syntax. If a user asks to create an image, direct them to the Image Creator option in the app.";
  if (style === "concise") return base + " Keep responses focused, direct, and concise.";
  if (style === "step-by-step") return base + " Break complex explanations into clear numbered steps with practical examples.";
  if (style === "creative") return base + " Offer imaginative, nuanced, and expressive insights with vivid examples.";
  return base + " Provide comprehensive, well-explained answers with helpful context and nuance.";
}

function cleanMessages(rawMessages: ChatTurnInput[]) {
  const valid = rawMessages
    .filter((m) => m && typeof m.text === "string" && m.text.trim())
    .slice(-12);

  const result: Array<{ role: "user" | "assistant"; content: string }> = [];
  for (const m of valid) {
    const role = m.role === "model" ? "assistant" : "user";
    const previous = result[result.length - 1];
    if (previous && previous.role === role) previous.content += `\n\n${m.text.trim()}`;
    else result.push({ role, content: m.text.trim() });
  }
  while (result[0]?.role === "assistant") result.shift();
  while (result[result.length - 1]?.role === "assistant") result.pop();
  return result;
}

function errorMessage(err: unknown): { status: number; message: string } {
  const raw = err instanceof Error ? err.message : String(err);
  if (raw.includes("401") || raw.includes("403"))
    return { status: 403, message: "AI server rejected the connection. Please check AI_API_KEY or the local AI server settings." };
  if (raw.includes("429"))
    return { status: 429, message: "The selected AI server is busy or rate-limited. Please try again shortly." };
  if (raw.includes("ECONNREFUSED") || raw.includes("fetch failed"))
    return { status: 503, message: "Local AI server is not running. Start Ollama/LM Studio (or another OpenAI-compatible server) and try again." };
  return { status: 500, message: raw || "An unexpected error occurred while generating a response." };
}

async function postChat(messages: Array<{ role: string; content: string }>, stream: boolean, style: string) {
  const { baseUrl, model, apiKey } = getAIConfig();
  const payload = {
    model,
    messages: [{ role: "system", content: buildSystemInstruction(style) }, ...messages],
    temperature: 0.7,
    stream,
  };
  const response = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(payload),
  });
  if (!response.ok) {
    const body = await response.text().catch(() => "");
    throw new Error(`${response.status}: ${body || response.statusText}`);
  }
  return response;
}

app.post("/api/chat/stream", async (req: Request, res: Response) => {
  const body = req.body as ChatRequestBody;
  const messages = cleanMessages(Array.isArray(body?.messages) ? body.messages : []);
  const style = body?.responseStyle || "detailed";
  if (!messages.length) {
    res.status(400).json({ error: "Please provide at least one message." });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders?.();

  try {
    const response = await postChat(messages, true, style);
    if (!response.body) throw new Error("AI server returned an empty stream.");
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const events = buffer.split("\n");
      buffer = events.pop() || "";

      for (const line of events) {
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (!data || data === "[DONE]") continue;
        try {
          const parsed = JSON.parse(data);
          const text = parsed?.choices?.[0]?.delta?.content;
          if (text) res.write(`data: ${JSON.stringify({ text })}\n\n`);
        } catch {
          // Ignore malformed SSE fragments.
        }
      }
    }
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    const { message } = errorMessage(err);
    res.write(`data: ${JSON.stringify({ error: message })}\n\n`);
    res.end();
  }
});

app.post("/api/chat", async (req: Request, res: Response) => {
  const body = req.body as ChatRequestBody;
  const messages = cleanMessages(Array.isArray(body?.messages) ? body.messages : []);
  const style = body?.responseStyle || "detailed";
  if (!messages.length) {
    res.status(400).json({ error: "Please provide at least one message." });
    return;
  }
  try {
    const response = await postChat(messages, false, style);
    const data = await response.json() as any;
    const text = data?.choices?.[0]?.message?.content || "";
    res.json({ text: sanitizeChatOutput(text) });
  } catch (err) {
    const { status, message } = errorMessage(err);
    res.status(status).json({ error: message });
  }
});

async function startServer() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let viteServer: any = null;
  const distPath = path.join(__dirname, "dist");
  const distIndex = path.join(distPath, "index.html");
  const isProduction = process.env.NODE_ENV === "production" || fs.existsSync(distIndex);

  if (isProduction) {
    app.use(express.static(distPath));
    app.get("*", (_req: Request, res: Response) => {
      if (fs.existsSync(distIndex)) res.sendFile(distIndex);
      else res.sendFile(path.join(__dirname, "index.html"));
    });
  } else {
    const { createServer: createViteServer } = await import("vite");
    viteServer = await createViteServer({ server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== "true" }, appType: "spa" });
    app.use(viteServer.middlewares);
    app.use("*", async (req: Request, res: Response, next) => {
      if (req.method !== "GET") return next();
      try {
        let template = fs.readFileSync(path.resolve(__dirname, "index.html"), "utf-8");
        template = await viteServer.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        viteServer.ssrFixStacktrace?.(e as Error);
        next(e);
      }
    });
  }

  const server = app.listen(PORT, "0.0.0.0", () => console.log(`Server listening on http://0.0.0.0:${PORT}`));
  server.on("error", (err: Error) => { console.error(err); process.exit(1); });
  const shutdown = async () => { if (viteServer) await viteServer.close(); server.close(() => process.exit(0)); };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}

startServer();
